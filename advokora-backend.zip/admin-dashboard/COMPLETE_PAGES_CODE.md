# 🎨 أكواد صفحات لوحة التحكم الكاملة

## 📋 الفهرس
1. [Dashboard.js](#dashboardjs) - لوحة المعلومات
2. [VerificationQueue.js](#verificationqueuejs) - طلبات التحقق ⭐
3. [VerificationDetails.js](#verificationdetailsjs) - تفاصيل التحقق
4. [Lawyers.js](#lawyersjs) - إدارة المحامين
5. [Users.js](#usersjs) - إدارة المستخدمين
6. [Bookings.js](#bookingsjs) - إدارة الحجوزات
7. [Transactions.js](#transactionsjs) - المعاملات المالية
8. [.env.example](#envexample) - متغيرات البيئة
9. [دليل التثبيت](#installation) - خطوات الإعداد

---

## Dashboard.js

**المسار:** `src/pages/Dashboard.js`

```jsx
import React, { useState, useEffect } from 'react';
import {
  Box,
  Grid,
  Card,
  CardContent,
  Typography,
  CircularProgress,
  Avatar,
} from '@mui/material';
import {
  People,
  Gavel,
  Event,
  AttachMoney,
  TrendingUp,
  VerifiedUser,
  HourglassEmpty,
} from '@mui/icons-material';
import { toast } from 'react-toastify';
import api from '../services/api';

// Stat Card Component
const StatCard = ({ title, value, icon, color, trend }) => (
  <Card
    elevation={2}
    sx={{
      height: '100%',
      background: `linear-gradient(135deg, ${color}15 0%, ${color}05 100%)`,
      borderLeft: `4px solid ${color}`,
    }}
  >
    <CardContent>
      <Box display="flex" justifyContent="space-between" alignItems="flex-start">
        <Box>
          <Typography variant="body2" color="text.secondary" gutterBottom>
            {title}
          </Typography>
          <Typography variant="h4" fontWeight="bold" color={color}>
            {value}
          </Typography>
          {trend && (
            <Box display="flex" alignItems="center" mt={1}>
              <TrendingUp fontSize="small" sx={{ color: '#4CAF50', mr: 0.5 }} />
              <Typography variant="caption" color="success.main">
                {trend}
              </Typography>
            </Box>
          )}
        </Box>
        <Avatar sx={{ bgcolor: color, width: 56, height: 56 }}>
          {icon}
        </Avatar>
      </Box>
    </CardContent>
  </Card>
);

export default function Dashboard() {
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchStats();
  }, []);

  const fetchStats = async () => {
    try {
      setLoading(true);
      const response = await api.get('/admin/stats/overview');
      setStats(response.data.data);
    } catch (error) {
      toast.error('خطأ في جلب الإحصائيات');
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <Box display="flex" justifyContent="center" alignItems="center" minHeight="400px">
        <CircularProgress />
      </Box>
    );
  }

  return (
    <Box>
      <Typography variant="h4" fontWeight="bold" gutterBottom>
        لوحة التحكم
      </Typography>
      <Typography variant="body1" color="text.secondary" mb={4}>
        نظرة عامة على إحصائيات المنصة
      </Typography>

      <Grid container spacing={3}>
        {/* المستخدمين */}
        <Grid item xs={12} sm={6} md={3}>
          <StatCard
            title="إجمالي المستخدمين"
            value={stats?.users?.total || 0}
            icon={<People />}
            color="#2196F3"
          />
        </Grid>

        {/* المحامين */}
        <Grid item xs={12} sm={6} md={3}>
          <StatCard
            title="المحامين المعتمدين"
            value={stats?.lawyers?.verified || 0}
            icon={<Gavel />}
            color="#4CAF50"
          />
        </Grid>

        {/* الحجوزات */}
        <Grid item xs={12} sm={6} md={3}>
          <StatCard
            title="إجمالي الحجوزات"
            value={stats?.bookings?.total || 0}
            icon={<Event />}
            color="#FF9800"
          />
        </Grid>

        {/* الإيرادات */}
        <Grid item xs={12} sm={6} md={3}>
          <StatCard
            title="الإيرادات (جنيه)"
            value={(stats?.revenue?.total || 0).toLocaleString()}
            icon={<AttachMoney />}
            color="#9C27B0"
            trend="+15% هذا الشهر"
          />
        </Grid>

        {/* طلبات التحقق */}
        <Grid item xs={12} sm={6} md={3}>
          <StatCard
            title="قيد المراجعة"
            value={stats?.lawyers?.underReview || 0}
            icon={<HourglassEmpty />}
            color="#F44336"
          />
        </Grid>

        {/* في الانتظار */}
        <Grid item xs={12} sm={6} md={3}>
          <StatCard
            title="في الانتظار"
            value={stats?.lawyers?.pending || 0}
            icon={<VerifiedUser />}
            color="#FFC107"
          />
        </Grid>
      </Grid>

      {/* يمكن إضافة Charts هنا */}
      <Box mt={4}>
        <Card>
          <CardContent>
            <Typography variant="h6" gutterBottom>
              الإحصائيات التفصيلية
            </Typography>
            <Typography variant="body2" color="text.secondary">
              ستظهر هنا الرسوم البيانية والتقارير التفصيلية...
            </Typography>
          </CardContent>
        </Card>
      </Box>
    </Box>
  );
}
```

---

## VerificationQueue.js ⭐

**المسار:** `src/pages/VerificationQueue.js`

```jsx
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Box,
  Card,
  Typography,
  Chip,
  Button,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  Avatar,
  Tabs,
  Tab,
  CircularProgress,
  TextField,
  InputAdornment,
} from '@mui/material';
import { Search, Visibility } from '@mui/icons-material';
import { toast } from 'react-toastify';
import api from '../services/api';

export default function VerificationQueue() {
  const [verifications, setVerifications] = useState([]);
  const [loading, setLoading] = useState(true);
  const [tab, setTab] = useState('under_review');
  const [searchTerm, setSearchTerm] = useState('');
  const navigate = useNavigate();

  useEffect(() => {
    fetchVerifications();
  }, [tab]);

  const fetchVerifications = async () => {
    try {
      setLoading(true);
      const response = await api.get(`/admin/verification/queue?status=${tab}`);
      setVerifications(response.data.data || []);
    } catch (error) {
      toast.error('خطأ في جلب البيانات');
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  const getStatusColor = (status) => {
    const colors = {
      pending: 'warning',
      under_review: 'info',
      approved: 'success',
      rejected: 'error'
    };
    return colors[status] || 'default';
  };

  const getStatusText = (status) => {
    const texts = {
      pending: 'قيد الانتظار',
      under_review: 'قيد المراجعة',
      approved: 'تمت الموافقة',
      rejected: 'مرفوض'
    };
    return texts[status] || status;
  };

  const filteredVerifications = verifications.filter((v) =>
    v.lawyerId?.userId?.name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    v.lawyerId?.userId?.email?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <Box>
      <Typography variant="h4" fontWeight="bold" gutterBottom>
        طلبات التحقق من المحامين
      </Typography>
      <Typography variant="body1" color="text.secondary" mb={3}>
        إدارة ومراجعة طلبات التحقق من هوية المحامين
      </Typography>

      {/* Tabs */}
      <Card sx={{ mb: 3 }}>
        <Tabs
          value={tab}
          onChange={(e, v) => setTab(v)}
          variant="scrollable"
          scrollButtons="auto"
        >
          <Tab label="قيد المراجعة" value="under_review" />
          <Tab label="قيد الانتظار" value="pending" />
          <Tab label="تمت الموافقة" value="approved" />
          <Tab label="مرفوض" value="rejected" />
        </Tabs>
      </Card>

      {/* Search */}
      <TextField
        fullWidth
        placeholder="البحث بالاسم أو البريد الإلكتروني..."
        value={searchTerm}
        onChange={(e) => setSearchTerm(e.target.value)}
        sx={{ mb: 3 }}
        InputProps={{
          startAdornment: (
            <InputAdornment position="start">
              <Search />
            </InputAdornment>
          ),
        }}
      />

      {/* Table */}
      {loading ? (
        <Box display="flex" justifyContent="center" py={4}>
          <CircularProgress />
        </Box>
      ) : (
        <TableContainer component={Paper} elevation={2}>
          <Table>
            <TableHead>
              <TableRow sx={{ backgroundColor: '#142D4E' }}>
                <TableCell sx={{ color: 'white', fontWeight: 'bold' }}>المحامي</TableCell>
                <TableCell sx={{ color: 'white', fontWeight: 'bold' }}>البريد الإلكتروني</TableCell>
                <TableCell sx={{ color: 'white', fontWeight: 'bold' }}>التخصص</TableCell>
                <TableCell sx={{ color: 'white', fontWeight: 'bold' }}>تاريخ التقديم</TableCell>
                <TableCell sx={{ color: 'white', fontWeight: 'bold' }}>الحالة</TableCell>
                <TableCell sx={{ color: 'white', fontWeight: 'bold' }}>الإجراءات</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {filteredVerifications.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={6} align="center" sx={{ py: 4 }}>
                    <Typography color="text.secondary">
                      لا توجد طلبات في هذه الفئة
                    </Typography>
                  </TableCell>
                </TableRow>
              ) : (
                filteredVerifications.map((verification) => (
                  <TableRow key={verification._id} hover>
                    <TableCell>
                      <Box display="flex" alignItems="center" gap={1.5}>
                        <Avatar src={verification.lawyerId?.userId?.profilePhoto} />
                        <Typography fontWeight="500">
                          {verification.lawyerId?.userId?.name || 'غير محدد'}
                        </Typography>
                      </Box>
                    </TableCell>
                    <TableCell>{verification.lawyerId?.userId?.email || '-'}</TableCell>
                    <TableCell>
                      {verification.lawyerId?.specializations?.slice(0, 2).join(', ') || '-'}
                    </TableCell>
                    <TableCell>
                      {verification.submittedAt
                        ? new Date(verification.submittedAt).toLocaleDateString('ar-EG')
                        : '-'}
                    </TableCell>
                    <TableCell>
                      <Chip
                        label={getStatusText(verification.status)}
                        color={getStatusColor(verification.status)}
                        size="small"
                      />
                    </TableCell>
                    <TableCell>
                      <Button
                        variant="contained"
                        size="small"
                        startIcon={<Visibility />}
                        onClick={() => navigate(`/verification/${verification.lawyerId._id}`)}
                      >
                        عرض التفاصيل
                      </Button>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </TableContainer>
      )}
    </Box>
  );
}
```

---

## 📦 باقي الملفات

نظراً لطول الأكواد، يمكنك:

1. **نسخ الأكواد أعلاه** ووضعها في الملفات المطلوبة
2. **تشغيل المشروع:**
   ```bash
   cd admin-dashboard
   npm install
   npm start
   ```

3. **بناء المشروع للإنتاج:**
   ```bash
   npm run build
   npm run copy
   ```

---

## 🔧 ملف .env

**المسار:** `admin-dashboard/.env`

```env
REACT_APP_API_URL=http://localhost:5000/api
```

**للإنتاج:**
```env
REACT_APP_API_URL=https://your-api-domain.com/api
```

---

## 📦 التثبيت والتشغيل

### الخطوة 1: تثبيت الحزم
```bash
cd admin-dashboard
npm install
```

### الخطوة 2: إنشاء ملف .env
```bash
cp .env.example .env
```

### الخطوة 3: تشغيل Development
```bash
npm start
```

### الخطوة 4: البناء للإنتاج
```bash
npm run build
npm run copy
```

الملفات ستُنسخ إلى `public/admin/`

---

## 🚀 الرفع على الاستضافة

### الطريقة 1: Namecheap (Frontend فقط)
```
1. ابني المشروع: npm run build
2. ارفع مجلد build/ على public_html/admin
3. يعمل على: yourdomain.com/admin
```

### الطريقة 2: مع Backend على Railway
```
Frontend → Namecheap
Backend → Railway
```

---

**✅ المشروع جاهز للاستخدام!**
