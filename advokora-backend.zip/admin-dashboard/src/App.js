import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { ThemeProvider } from '@mui/material/styles';
import { CssBaseline, Box } from '@mui/material';
import rtlPlugin from 'stylis-plugin-rtl';
import { CacheProvider } from '@emotion/react';
import createCache from '@emotion/cache';
import { prefixer } from 'stylis';
import { ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

import theme from './theme';
import Layout from './components/Layout';
import Login from './pages/Login';
import Dashboard from './pages/Dashboard';
import VerificationQueue from './pages/VerificationQueue';
import VerificationDetails from './pages/VerificationDetails';
import Lawyers from './pages/Lawyers';
import Users from './pages/Users';
import Bookings from './pages/Bookings';
import Transactions from './pages/Transactions';
import { isAuthenticated } from './services/auth';

// RTL Cache
const cacheRtl = createCache({
  key: 'muirtl',
  stylisPlugins: [prefixer, rtlPlugin],
});

// Protected Route Component
const ProtectedRoute = ({ children }) => {
  return isAuthenticated() ? children : <Navigate to="/login" replace />;
};

function App() {
  return (
    <CacheProvider value={cacheRtl}>
      <ThemeProvider theme={theme}>
        <CssBaseline />
        <Router basename="/admin">
          <Routes>
            {/* Public Routes */}
            <Route path="/login" element={<Login />} />

            {/* Protected Routes */}
            <Route
              path="/*"
              element={
                <ProtectedRoute>
                  <Layout>
                    <Routes>
                      <Route path="/" element={<Dashboard />} />
                      <Route path="/verification" element={<VerificationQueue />} />
                      <Route path="/verification/:id" element={<VerificationDetails />} />
                      <Route path="/lawyers" element={<Lawyers />} />
                      <Route path="/users" element={<Users />} />
                      <Route path="/bookings" element={<Bookings />} />
                      <Route path="/transactions" element={<Transactions />} />
                      <Route path="*" element={<Navigate to="/" replace />} />
                    </Routes>
                  </Layout>
                </ProtectedRoute>
              }
            />
          </Routes>
        </Router>

        {/* Toast Notifications */}
        <ToastContainer
          position="top-left"
          autoClose={3000}
          rtl={true}
          theme="colored"
        />
      </ThemeProvider>
    </CacheProvider>
  );
}

export default App;
