import api from './api';

// تسجيل الدخول
export const login = async (email, password) => {
  const response = await api.post('/auth/login', { email, password });
  
  if (response.data.success) {
    const { token, user } = response.data.data;
    
    // التحقق من أن المستخدم Admin
    if (user.role !== 'admin') {
      throw new Error('ليس لديك صلاحية الوصول لهذه اللوحة');
    }
    
    localStorage.setItem('token', token);
    localStorage.setItem('user', JSON.stringify(user));
  }
  
  return response.data;
};

// تسجيل الخروج
export const logout = () => {
  localStorage.removeItem('token');
  localStorage.removeItem('user');
  window.location.href = '/admin/login';
};

// الحصول على المستخدم الحالي
export const getCurrentUser = () => {
  const user = localStorage.getItem('user');
  return user ? JSON.parse(user) : null;
};

// التحقق من المصادقة
export const isAuthenticated = () => {
  const token = localStorage.getItem('token');
  const user = getCurrentUser();
  return !!(token && user && user.role === 'admin');
};

// الحصول على Token
export const getToken = () => {
  return localStorage.getItem('token');
};
