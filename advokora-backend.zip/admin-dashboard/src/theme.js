import { createTheme } from '@mui/material/styles';

// ألوان التطبيق الأصلية من Flutter
const theme = createTheme({
  direction: 'rtl',
  palette: {
    primary: {
      main: '#142D4E', // Navy Blue
      dark: '#0F1A2E',
      light: '#2D4263',
      contrastText: '#FFFFFF',
    },
    secondary: {
      main: '#C6A56A', // Gold
      light: '#E8C85A',
      dark: '#B8941E',
      contrastText: '#FFFFFF',
    },
    background: {
      default: '#FAF9F6', // أبيض عاجي
      paper: '#FFFFFF',
    },
    text: {
      primary: '#2C2C2C',
      secondary: '#6B6B6B',
    },
    success: {
      main: '#4CAF50',
    },
    error: {
      main: '#D32F2F',
    },
    warning: {
      main: '#FF9800',
    },
    info: {
      main: '#2196F3',
    },
  },
  typography: {
    fontFamily: "'Cairo', 'Roboto', 'Helvetica', 'Arial', sans-serif",
    h1: {
      fontWeight: 700,
    },
    h2: {
      fontWeight: 700,
    },
    h3: {
      fontWeight: 600,
    },
    h4: {
      fontWeight: 600,
    },
    h5: {
      fontWeight: 600,
    },
    h6: {
      fontWeight: 600,
    },
    button: {
      fontWeight: 600,
      textTransform: 'none',
    },
  },
  shape: {
    borderRadius: 12,
  },
  components: {
    MuiButton: {
      styleOverrides: {
        root: {
          borderRadius: 12,
          padding: '10px 24px',
          fontSize: '1rem',
        },
        contained: {
          boxShadow: '0 4px 12px rgba(20, 45, 78, 0.15)',
          '&:hover': {
            boxShadow: '0 6px 16px rgba(20, 45, 78, 0.25)',
          },
        },
      },
    },
    MuiCard: {
      styleOverrides: {
        root: {
          borderRadius: 16,
          boxShadow: '0 2px 12px rgba(0, 0, 0, 0.08)',
        },
      },
    },
    MuiPaper: {
      styleOverrides: {
        root: {
          borderRadius: 12,
        },
      },
    },
    MuiChip: {
      styleOverrides: {
        root: {
          borderRadius: 8,
          fontWeight: 600,
        },
      },
    },
  },
});

export default theme;
