require('dotenv').config();
const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');
const path = require('path');
const fs = require('fs-extra');

// Initialize Express
const app = express();

// Middleware
app.use(helmet({
  crossOriginResourcePolicy: { policy: "cross-origin" },
  contentSecurityPolicy: false
}));
app.use(cors());
app.use(morgan('dev'));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Create uploads directories if they don't exist
const uploadDirs = [
  'public/uploads/profiles',
  'public/uploads/ids',
  'public/uploads/bar-cards',
  'public/uploads/documents'
];

uploadDirs.forEach(dir => {
  fs.ensureDirSync(path.join(__dirname, dir));
});

// Database Connection
mongoose.connect(process.env.MONGODB_URI || 'mongodb://localhost:27017/advokora', {
  useNewUrlParser: true,
  useUnifiedTopology: true,
})
  .then(() => console.log('✅ MongoDB Connected'))
  .catch(err => {
    console.error('❌ MongoDB Connection Error:', err.message);
    process.exit(1);
  });

// API Routes
app.use('/api/auth', require('./src/routes/auth'));
app.use('/api/lawyers', require('./src/routes/lawyers'));
app.use('/api/bookings', require('./src/routes/bookings'));
app.use('/api/payments', require('./src/routes/payments'));
app.use('/api/wallet', require('./src/routes/wallet'));
app.use('/api/reviews', require('./src/routes/reviews'));
app.use('/api/upload', require('./src/routes/upload'));

// Admin Routes
app.use('/api/admin', require('./src/routes/admin'));

// Serve uploaded files
app.use('/uploads', express.static(path.join(__dirname, 'public/uploads')));

// Serve Admin Dashboard (Static Files)
app.use('/admin', express.static(path.join(__dirname, 'public/admin')));

// Admin Dashboard - React Router (SPA)
app.get('/admin/*', (req, res) => {
  const indexPath = path.join(__dirname, 'public/admin/index.html');
  if (fs.existsSync(indexPath)) {
    res.sendFile(indexPath);
  } else {
    res.status(404).send('Admin dashboard not built yet. Run: npm run build:admin');
  }
});

// API Root
app.get('/api', (req, res) => {
  res.json({
    success: true,
    message: 'Advokora API is running',
    version: '1.0.0',
    endpoints: {
      auth: '/api/auth',
      users: '/api/auth',
      lawyers: '/api/lawyers',
      bookings: '/api/bookings',
      payments: '/api/payments',
      wallet: '/api/wallet',
      reviews: '/api/reviews',
      admin: '/api/admin',
      uploads: '/uploads'
    }
  });
});

// Root
app.get('/', (req, res) => {
  res.json({
    success: true,
    message: 'Advokora Backend API',
    admin: '/admin',
    api: '/api'
  });
});

// 404 Handler
app.use((req, res) => {
  res.status(404).json({
    success: false,
    message: 'Route not found'
  });
});

// Error Handler
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(err.status || 500).json({
    success: false,
    message: err.message || 'Internal Server Error',
    ...(process.env.NODE_ENV === 'development' && { stack: err.stack })
  });
});

// Start Server
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`
  ╔═══════════════════════════════════════════╗
  ║   🚀 Advokora Backend Server Running     ║
  ║                                           ║
  ║   Port: ${PORT}                              ║
  ║   Environment: ${process.env.NODE_ENV || 'development'}              ║
  ║                                           ║
  ║   API: http://localhost:${PORT}/api         ║
  ║   Admin: http://localhost:${PORT}/admin     ║
  ║   Uploads: http://localhost:${PORT}/uploads ║
  ╚═══════════════════════════════════════════╝
  `);
});

// Handle unhandled promise rejections
process.on('unhandledRejection', (err) => {
  console.error('❌ Unhandled Promise Rejection:', err);
  process.exit(1);
});
