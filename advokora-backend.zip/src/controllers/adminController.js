const User = require('../models/User');
const Lawyer = require('../models/Lawyer');
const LawyerVerification = require('../models/LawyerVerification');
const Booking = require('../models/Booking');
const Transaction = require('../models/Transaction');
const Wallet = require('../models/Wallet');

// ============ VERIFICATION ============

// @desc    Get verification queue
// @route   GET /api/admin/verification/queue
// @access  Private (Admin only)
exports.getVerificationQueue = async (req, res) => {
  try {
    const { status = 'under_review', page = 1, limit = 20 } = req.query;
    const skip = (page - 1) * limit;

    const verifications = await LawyerVerification.find({ status })
      .populate({
        path: 'lawyerId',
        populate: {
          path: 'userId',
          select: 'name email phone profilePhoto country city'
        }
      })
      .sort('-submittedAt')
      .skip(skip)
      .limit(parseInt(limit));

    const total = await LawyerVerification.countDocuments({ status });

    res.json({
      success: true,
      data: verifications,
      pagination: {
        page: parseInt(page),
        limit: parseInt(limit),
        total,
        pages: Math.ceil(total / limit)
      }
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};

// @desc    Get verification details
// @route   GET /api/admin/verification/:lawyerId
// @access  Private (Admin only)
exports.getVerificationDetails = async (req, res) => {
  try {
    const verification = await LawyerVerification.findOne({ 
      lawyerId: req.params.lawyerId 
    })
      .populate({
        path: 'lawyerId',
        populate: {
          path: 'userId',
          select: 'name email phone profilePhoto country city dateOfBirth gender'
        }
      })
      .populate('reviewedBy', 'name email');

    if (!verification) {
      return res.status(404).json({
        success: false,
        message: 'Verification not found'
      });
    }

    res.json({
      success: true,
      data: verification
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};

// @desc    Approve lawyer verification
// @route   PUT /api/admin/verification/:lawyerId/approve
// @access  Private (Admin only)
exports.approveLawyer = async (req, res) => {
  try {
    const { notes } = req.body;

    const verification = await LawyerVerification.findOne({ 
      lawyerId: req.params.lawyerId 
    });

    if (!verification) {
      return res.status(404).json({
        success: false,
        message: 'Verification not found'
      });
    }

    // Check if all documents are present
    if (!verification.areAllDocumentsUploaded()) {
      return res.status(400).json({
        success: false,
        message: 'Not all required documents are uploaded'
      });
    }

    // Approve all documents
    if (verification.documents.nationalIdFront) {
      verification.documents.nationalIdFront.status = 'approved';
    }
    if (verification.documents.nationalIdBack) {
      verification.documents.nationalIdBack.status = 'approved';
    }
    if (verification.documents.barCard) {
      verification.documents.barCard.status = 'approved';
    }
    if (verification.documents.personalPhoto) {
      verification.documents.personalPhoto.status = 'approved';
    }

    verification.status = 'approved';
    verification.reviewedAt = new Date();
    verification.reviewedBy = req.user._id;
    verification.adminNotes = notes;
    verification.addReviewHistory(req.user._id, 'approved', notes);

    await verification.save();

    // Update lawyer status
    await Lawyer.findByIdAndUpdate(req.params.lawyerId, {
      verificationStatus: 'verified',
      verifiedAt: new Date(),
      isAvailable: true,
      rejectionReason: null
    });

    res.json({
      success: true,
      message: 'Lawyer approved successfully',
      data: verification
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};

// @desc    Reject lawyer verification
// @route   PUT /api/admin/verification/:lawyerId/reject
// @access  Private (Admin only)
exports.rejectLawyer = async (req, res) => {
  try {
    const { reason, notes } = req.body;

    if (!reason) {
      return res.status(400).json({
        success: false,
        message: 'Rejection reason is required'
      });
    }

    const verification = await LawyerVerification.findOne({ 
      lawyerId: req.params.lawyerId 
    });

    if (!verification) {
      return res.status(404).json({
        success: false,
        message: 'Verification not found'
      });
    }

    verification.status = 'rejected';
    verification.rejectionReason = reason;
    verification.reviewedAt = new Date();
    verification.reviewedBy = req.user._id;
    verification.adminNotes = notes;
    verification.addReviewHistory(req.user._id, 'rejected', notes || reason);

    await verification.save();

    // Update lawyer status
    await Lawyer.findByIdAndUpdate(req.params.lawyerId, {
      verificationStatus: 'rejected',
      rejectionReason: reason,
      isAvailable: false
    });

    res.json({
      success: true,
      message: 'Lawyer verification rejected',
      data: verification
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};

// ============ STATS ============

// @desc    Get dashboard stats
// @route   GET /api/admin/stats/overview
// @access  Private (Admin only)
exports.getDashboardStats = async (req, res) => {
  try {
    const totalUsers = await User.countDocuments({ role: 'client' });
    const totalLawyers = await Lawyer.countDocuments();
    const verifiedLawyers = await Lawyer.countDocuments({ verificationStatus: 'verified' });
    const pendingVerification = await Lawyer.countDocuments({ verificationStatus: 'pending' });
    const underReview = await Lawyer.countDocuments({ verificationStatus: 'under_review' });
    
    const totalBookings = await Booking.countDocuments();
    const completedBookings = await Booking.countDocuments({ status: 'completed' });
    const pendingBookings = await Booking.countDocuments({ status: 'pending' });
    
    const totalRevenue = await Transaction.aggregate([
      { $match: { status: 'completed', type: 'commission' } },
      { $group: { _id: null, total: { $sum: '$amount' } } }
    ]);

    const monthlyRevenue = await Transaction.aggregate([
      {
        $match: {
          status: 'completed',
          type: 'commission',
          createdAt: { $gte: new Date(new Date().setDate(1)) }
        }
      },
      { $group: { _id: null, total: { $sum: '$amount' } } }
    ]);

    res.json({
      success: true,
      data: {
        users: {
          total: totalUsers,
          active: await User.countDocuments({ role: 'client', isActive: true })
        },
        lawyers: {
          total: totalLawyers,
          verified: verifiedLawyers,
          pending: pendingVerification,
          underReview
        },
        bookings: {
          total: totalBookings,
          completed: completedBookings,
          pending: pendingBookings
        },
        revenue: {
          total: totalRevenue[0]?.total || 0,
          monthly: monthlyRevenue[0]?.total || 0
        }
      }
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};

// ============ LAWYERS MANAGEMENT ============

// @desc    Get all lawyers (admin)
// @route   GET /api/admin/lawyers
// @access  Private (Admin only)
exports.getAllLawyers = async (req, res) => {
  try {
    const { status, page = 1, limit = 20 } = req.query;
    const skip = (page - 1) * limit;

    let query = {};
    if (status) {
      query.verificationStatus = status;
    }

    const lawyers = await Lawyer.find(query)
      .populate('userId', 'name email phone profilePhoto country city isActive')
      .sort('-createdAt')
      .skip(skip)
      .limit(parseInt(limit));

    const total = await Lawyer.countDocuments(query);

    res.json({
      success: true,
      data: lawyers,
      pagination: {
        page: parseInt(page),
        limit: parseInt(limit),
        total,
        pages: Math.ceil(total / limit)
      }
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};

// @desc    Suspend lawyer
// @route   PUT /api/admin/lawyers/:id/suspend
// @access  Private (Admin only)
exports.suspendLawyer = async (req, res) => {
  try {
    const lawyer = await Lawyer.findByIdAndUpdate(
      req.params.id,
      { isAvailable: false },
      { new: true }
    );

    if (!lawyer) {
      return res.status(404).json({
        success: false,
        message: 'Lawyer not found'
      });
    }

    await User.findByIdAndUpdate(lawyer.userId, { isActive: false });

    res.json({
      success: true,
      message: 'Lawyer suspended successfully',
      data: lawyer
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};

// @desc    Activate lawyer
// @route   PUT /api/admin/lawyers/:id/activate
// @access  Private (Admin only)
exports.activateLawyer = async (req, res) => {
  try {
    const lawyer = await Lawyer.findByIdAndUpdate(
      req.params.id,
      { isAvailable: true },
      { new: true }
    );

    if (!lawyer) {
      return res.status(404).json({
        success: false,
        message: 'Lawyer not found'
      });
    }

    await User.findByIdAndUpdate(lawyer.userId, { isActive: true });

    res.json({
      success: true,
      message: 'Lawyer activated successfully',
      data: lawyer
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};

// ============ USERS MANAGEMENT ============

// @desc    Get all users
// @route   GET /api/admin/users
// @access  Private (Admin only)
exports.getAllUsers = async (req, res) => {
  try {
    const { role, isActive, page = 1, limit = 20 } = req.query;
    const skip = (page - 1) * limit;

    let query = {};
    if (role) query.role = role;
    if (isActive !== undefined) query.isActive = isActive === 'true';

    const users = await User.find(query)
      .select('-password')
      .sort('-createdAt')
      .skip(skip)
      .limit(parseInt(limit));

    const total = await User.countDocuments(query);

    res.json({
      success: true,
      data: users,
      pagination: {
        page: parseInt(page),
        limit: parseInt(limit),
        total,
        pages: Math.ceil(total / limit)
      }
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};

// @desc    Suspend user
// @route   PUT /api/admin/users/:id/suspend
// @access  Private (Admin only)
exports.suspendUser = async (req, res) => {
  try {
    const user = await User.findByIdAndUpdate(
      req.params.id,
      { isActive: false },
      { new: true }
    ).select('-password');

    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'User not found'
      });
    }

    res.json({
      success: true,
      message: 'User suspended successfully',
      data: user
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};

// @desc    Activate user
// @route   PUT /api/admin/users/:id/activate
// @access  Private (Admin only)
exports.activateUser = async (req, res) => {
  try {
    const user = await User.findByIdAndUpdate(
      req.params.id,
      { isActive: true },
      { new: true }
    ).select('-password');

    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'User not found'
      });
    }

    res.json({
      success: true,
      message: 'User activated successfully',
      data: user
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};

// ============ BOOKINGS MANAGEMENT ============

// @desc    Get all bookings
// @route   GET /api/admin/bookings
// @access  Private (Admin only)
exports.getAllBookings = async (req, res) => {
  try {
    const { status, page = 1, limit = 20 } = req.query;
    const skip = (page - 1) * limit;

    let query = {};
    if (status) query.status = status;

    const bookings = await Booking.find(query)
      .populate('clientId', 'name email phone')
      .populate({
        path: 'lawyerId',
        populate: {
          path: 'userId',
          select: 'name email phone'
        }
      })
      .sort('-createdAt')
      .skip(skip)
      .limit(parseInt(limit));

    const total = await Booking.countDocuments(query);

    res.json({
      success: true,
      data: bookings,
      pagination: {
        page: parseInt(page),
        limit: parseInt(limit),
        total,
        pages: Math.ceil(total / limit)
      }
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};

// ============ TRANSACTIONS MANAGEMENT ============

// @desc    Get all transactions
// @route   GET /api/admin/transactions
// @access  Private (Admin only)
exports.getAllTransactions = async (req, res) => {
  try {
    const { type, status, page = 1, limit = 20 } = req.query;
    const skip = (page - 1) * limit;

    let query = {};
    if (type) query.type = type;
    if (status) query.status = status;

    const transactions = await Transaction.find(query)
      .populate('userId', 'name email')
      .sort('-createdAt')
      .skip(skip)
      .limit(parseInt(limit));

    const total = await Transaction.countDocuments(query);

    res.json({
      success: true,
      data: transactions,
      pagination: {
        page: parseInt(page),
        limit: parseInt(limit),
        total,
        pages: Math.ceil(total / limit)
      }
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};

// @desc    Approve withdrawal
// @route   PUT /api/admin/transactions/:id/approve-withdrawal
// @access  Private (Admin only)
exports.approveWithdrawal = async (req, res) => {
  try {
    const transaction = await Transaction.findById(req.params.id);

    if (!transaction) {
      return res.status(404).json({
        success: false,
        message: 'Transaction not found'
      });
    }

    if (transaction.type !== 'walletWithdraw') {
      return res.status(400).json({
        success: false,
        message: 'Not a withdrawal transaction'
      });
    }

    if (transaction.status !== 'pending') {
      return res.status(400).json({
        success: false,
        message: 'Transaction already processed'
      });
    }

    transaction.status = 'completed';
    transaction.completedAt = new Date();
    await transaction.save();

    // Update wallet
    const wallet = await Wallet.findById(transaction.walletId);
    wallet.pendingBalance -= transaction.amount;
    wallet.totalWithdrawals += transaction.amount;
    await wallet.save();

    res.json({
      success: true,
      message: 'Withdrawal approved successfully',
      data: transaction
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};

// @desc    Reject withdrawal
// @route   PUT /api/admin/transactions/:id/reject-withdrawal
// @access  Private (Admin only)
exports.rejectWithdrawal = async (req, res) => {
  try {
    const { reason } = req.body;

    const transaction = await Transaction.findById(req.params.id);

    if (!transaction) {
      return res.status(404).json({
        success: false,
        message: 'Transaction not found'
      });
    }

    if (transaction.type !== 'walletWithdraw') {
      return res.status(400).json({
        success: false,
        message: 'Not a withdrawal transaction'
      });
    }

    if (transaction.status !== 'pending') {
      return res.status(400).json({
        success: false,
        message: 'Transaction already processed'
      });
    }

    transaction.status = 'failed';
    transaction.failedReason = reason || 'Rejected by admin';
    await transaction.save();

    // Return to available balance
    const wallet = await Wallet.findById(transaction.walletId);
    wallet.pendingBalance -= transaction.amount;
    wallet.availableBalance += transaction.amount;
    await wallet.save();

    res.json({
      success: true,
      message: 'Withdrawal rejected',
      data: transaction
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};
