const Booking = require('../models/Booking');
const Lawyer = require('../models/Lawyer');
const Payment = require('../models/Payment');
const Transaction = require('../models/Transaction');
const Wallet = require('../models/Wallet');

// @desc    Create booking
// @route   POST /api/bookings
// @access  Private (Client only)
exports.createBooking = async (req, res) => {
  try {
    const { lawyerId, date, time, consultationType, issue, description } = req.body;

    // Check if lawyer exists and is available
    const lawyer = await Lawyer.findById(lawyerId);
    if (!lawyer) {
      return res.status(404).json({
        success: false,
        message: 'Lawyer not found'
      });
    }

    if (!lawyer.isAvailable || lawyer.verificationStatus !== 'verified') {
      return res.status(400).json({
        success: false,
        message: 'Lawyer is not available for booking'
      });
    }

    // Create booking
    const booking = await Booking.create({
      clientId: req.user._id,
      lawyerId,
      date,
      time,
      consultationType,
      issue,
      description,
      consultationPrice: lawyer.consultationPrice,
      currency: lawyer.currency
    });

    await booking.populate('lawyerId', 'userId specializations consultationPrice');
    await booking.populate('clientId', 'name phone email');

    res.status(201).json({
      success: true,
      message: 'Booking created successfully',
      data: booking
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};

// @desc    Get user bookings
// @route   GET /api/bookings
// @access  Private
exports.getMyBookings = async (req, res) => {
  try {
    const { status, page = 1, limit = 10 } = req.query;
    const skip = (page - 1) * limit;

    let query = {};
    
    // Check user role
    if (req.user.role === 'client') {
      query.clientId = req.user._id;
    } else if (req.user.role === 'lawyer') {
      const lawyer = await Lawyer.findOne({ userId: req.user._id });
      if (!lawyer) {
        return res.status(404).json({
          success: false,
          message: 'Lawyer profile not found'
        });
      }
      query.lawyerId = lawyer._id;
    }

    if (status) {
      query.status = status;
    }

    const bookings = await Booking.find(query)
      .populate('lawyerId', 'specializations consultationPrice')
      .populate({
        path: 'lawyerId',
        populate: {
          path: 'userId',
          select: 'name email phone profilePhoto'
        }
      })
      .populate('clientId', 'name email phone profilePhoto')
      .sort('-createdAt')
      .skip(skip)
      .limit(parseInt(limit));

    const total = await Booking.countDocuments(query);

    res.json({
      success: true,
      data: bookings,
      pagination: {
        page: parseInt(page),
        limit: parseInt(limit),
        total,
        pages: Math.ceil(total / limit)
      }
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};

// @desc    Get single booking
// @route   GET /api/bookings/:id
// @access  Private
exports.getBooking = async (req, res) => {
  try {
    const booking = await Booking.findById(req.params.id)
      .populate('lawyerId', 'specializations consultationPrice')
      .populate({
        path: 'lawyerId',
        populate: {
          path: 'userId',
          select: 'name email phone profilePhoto'
        }
      })
      .populate('clientId', 'name email phone profilePhoto');

    if (!booking) {
      return res.status(404).json({
        success: false,
        message: 'Booking not found'
      });
    }

    // Check authorization
    const lawyer = await Lawyer.findOne({ userId: req.user._id });
    const isOwner = booking.clientId._id.toString() === req.user._id.toString() ||
                    (lawyer && booking.lawyerId._id.toString() === lawyer._id.toString());

    if (!isOwner && req.user.role !== 'admin') {
      return res.status(403).json({
        success: false,
        message: 'Not authorized to view this booking'
      });
    }

    res.json({
      success: true,
      data: booking
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};

// @desc    Update booking status
// @route   PUT /api/bookings/:id/status
// @access  Private (Lawyer only)
exports.updateBookingStatus = async (req, res) => {
  try {
    const { status, rejectionReason } = req.body;

    const booking = await Booking.findById(req.params.id);

    if (!booking) {
      return res.status(404).json({
        success: false,
        message: 'Booking not found'
      });
    }

    // Check if user is the lawyer
    const lawyer = await Lawyer.findOne({ userId: req.user._id });
    if (!lawyer || booking.lawyerId.toString() !== lawyer._id.toString()) {
      return res.status(403).json({
        success: false,
        message: 'Not authorized to update this booking'
      });
    }

    // Validate status transitions
    const validTransitions = {
      'pending': ['confirmed', 'rejected'],
      'confirmed': ['completed', 'cancelled'],
      'completed': [],
      'cancelled': [],
      'rejected': []
    };

    if (!validTransitions[booking.status].includes(status)) {
      return res.status(400).json({
        success: false,
        message: `Cannot change status from ${booking.status} to ${status}`
      });
    }

    booking.status = status;

    if (status === 'rejected' && rejectionReason) {
      booking.rejectionReason = rejectionReason;
    }

    if (status === 'confirmed') {
      booking.confirmedAt = new Date();
    }

    if (status === 'completed') {
      booking.completedAt = new Date();
      
      // Release payment to lawyer
      // Create commission transaction
      const commissionRate = parseFloat(process.env.COMMISSION_RATE) || 0.10;
      const commissionAmount = booking.consultationPrice * commissionRate;
      const lawyerAmount = booking.consultationPrice - commissionAmount;

      // Update lawyer's wallet
      const lawyerUser = await lawyer.populate('userId');
      const lawyerWallet = await Wallet.findOne({ userId: lawyerUser.userId._id });
      
      if (lawyerWallet) {
        await lawyerWallet.releasePending(booking.consultationPrice);
      }

      // Create commission transaction
      await Transaction.create({
        userId: lawyerUser.userId._id,
        bookingId: booking._id,
        type: 'commission',
        amount: commissionAmount,
        status: 'completed',
        description: `Commission for booking ${booking.bookingId}`,
        commission: {
          amount: commissionAmount,
          percentage: commissionRate * 100
        }
      });
    }

    await booking.save();

    res.json({
      success: true,
      message: `Booking ${status} successfully`,
      data: booking
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};

// @desc    Cancel booking
// @route   PUT /api/bookings/:id/cancel
// @access  Private (Client only)
exports.cancelBooking = async (req, res) => {
  try {
    const { reason } = req.body;

    const booking = await Booking.findById(req.params.id);

    if (!booking) {
      return res.status(404).json({
        success: false,
        message: 'Booking not found'
      });
    }

    // Check authorization
    if (booking.clientId.toString() !== req.user._id.toString()) {
      return res.status(403).json({
        success: false,
        message: 'Not authorized to cancel this booking'
      });
    }

    // Can only cancel pending or confirmed bookings
    if (!['pending', 'confirmed'].includes(booking.status)) {
      return res.status(400).json({
        success: false,
        message: 'Cannot cancel this booking'
      });
    }

    booking.status = 'cancelled';
    booking.cancellationReason = reason;
    booking.cancelledAt = new Date();
    booking.cancelledBy = req.user._id;

    await booking.save();

    // Refund if payment was made
    const payment = await Payment.findOne({ bookingId: booking._id, status: 'completed' });
    if (payment) {
      // Process refund based on payment method
      if (payment.paymentMethod === 'wallet') {
        const wallet = await Wallet.findOne({ userId: req.user._id });
        await wallet.deposit(payment.amount);

        await Transaction.create({
          userId: req.user._id,
          bookingId: booking._id,
          type: 'refund',
          amount: payment.amount,
          status: 'completed',
          paymentMethod: 'wallet',
          description: `Refund for cancelled booking ${booking.bookingId}`
        });
      }

      payment.status = 'refunded';
      payment.refundedAt = new Date();
      payment.refundAmount = payment.amount;
      payment.refundReason = 'Booking cancelled by client';
      await payment.save();
    }

    res.json({
      success: true,
      message: 'Booking cancelled successfully',
      data: booking
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};
