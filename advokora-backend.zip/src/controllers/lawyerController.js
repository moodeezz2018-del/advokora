const Lawyer = require('../models/Lawyer');
const User = require('../models/User');
const LawyerVerification = require('../models/LawyerVerification');

// @desc    Get all verified lawyers
// @route   GET /api/lawyers
// @access  Public
exports.getLawyers = async (req, res) => {
  try {
    const { 
      specialization, 
      barDegree, 
      minPrice, 
      maxPrice, 
      rating,
      country,
      city,
      page = 1,
      limit = 10,
      sort = '-rating'
    } = req.query;

    // Build query
    let query = { verificationStatus: 'verified' };

    if (specialization) {
      query.specializations = { $in: [specialization] };
    }

    if (barDegree) {
      query.barDegree = barDegree;
    }

    if (minPrice || maxPrice) {
      query.consultationPrice = {};
      if (minPrice) query.consultationPrice.$gte = parseFloat(minPrice);
      if (maxPrice) query.consultationPrice.$lte = parseFloat(maxPrice);
    }

    if (rating) {
      query.rating = { $gte: parseFloat(rating) };
    }

    // Pagination
    const skip = (parseInt(page) - 1) * parseInt(limit);

    const lawyers = await Lawyer.find(query)
      .populate({
        path: 'userId',
        select: 'name email phone profilePhoto country city',
        match: country || city ? { 
          ...(country && { country }), 
          ...(city && { city }) 
        } : {}
      })
      .sort(sort)
      .skip(skip)
      .limit(parseInt(limit));

    // Filter out lawyers whose user doesn't match location
    const filteredLawyers = lawyers.filter(lawyer => lawyer.userId !== null);

    const total = await Lawyer.countDocuments(query);

    res.json({
      success: true,
      data: filteredLawyers,
      pagination: {
        page: parseInt(page),
        limit: parseInt(limit),
        total,
        pages: Math.ceil(total / parseInt(limit))
      }
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};

// @desc    Get single lawyer
// @route   GET /api/lawyers/:id
// @access  Public
exports.getLawyer = async (req, res) => {
  try {
    const lawyer = await Lawyer.findById(req.params.id)
      .populate('userId', 'name email phone profilePhoto country city bio');

    if (!lawyer) {
      return res.status(404).json({
        success: false,
        message: 'Lawyer not found'
      });
    }

    res.json({
      success: true,
      data: lawyer
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};

// @desc    Register as lawyer
// @route   POST /api/lawyers/register
// @access  Private
exports.registerLawyer = async (req, res) => {
  try {
    const userId = req.user._id;

    // Check if user is already a lawyer
    const existingLawyer = await Lawyer.findOne({ userId });
    if (existingLawyer) {
      return res.status(400).json({
        success: false,
        message: 'You are already registered as a lawyer'
      });
    }

    const {
      barDegree,
      specializations,
      yearsOfExperience,
      licenseNumber,
      barAssociation,
      consultationPrice,
      currency,
      languages,
      description
    } = req.body;

    // Create lawyer profile
    const lawyer = await Lawyer.create({
      userId,
      barDegree,
      specializations,
      yearsOfExperience,
      licenseNumber,
      barAssociation,
      consultationPrice,
      currency,
      languages,
      description
    });

    // Create verification record
    await LawyerVerification.create({
      lawyerId: lawyer._id
    });

    // Update user role
    await User.findByIdAndUpdate(userId, { role: 'lawyer' });

    res.status(201).json({
      success: true,
      message: 'Lawyer registration successful. Please upload verification documents.',
      data: lawyer
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};

// @desc    Update lawyer profile
// @route   PUT /api/lawyers/:id
// @access  Private (Lawyer only)
exports.updateLawyer = async (req, res) => {
  try {
    let lawyer = await Lawyer.findById(req.params.id);

    if (!lawyer) {
      return res.status(404).json({
        success: false,
        message: 'Lawyer not found'
      });
    }

    // Check ownership
    if (lawyer.userId.toString() !== req.user._id.toString()) {
      return res.status(403).json({
        success: false,
        message: 'Not authorized to update this profile'
      });
    }

    const fieldsToUpdate = {
      specializations: req.body.specializations,
      yearsOfExperience: req.body.yearsOfExperience,
      consultationPrice: req.body.consultationPrice,
      workingHours: req.body.workingHours,
      languages: req.body.languages,
      description: req.body.description,
      isAvailable: req.body.isAvailable
    };

    // Remove undefined fields
    Object.keys(fieldsToUpdate).forEach(key => 
      fieldsToUpdate[key] === undefined && delete fieldsToUpdate[key]
    );

    lawyer = await Lawyer.findByIdAndUpdate(
      req.params.id,
      fieldsToUpdate,
      { new: true, runValidators: true }
    );

    res.json({
      success: true,
      message: 'Lawyer profile updated successfully',
      data: lawyer
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};

// @desc    Search lawyers
// @route   GET /api/lawyers/search
// @access  Public
exports.searchLawyers = async (req, res) => {
  try {
    const { q, page = 1, limit = 10 } = req.query;

    if (!q) {
      return res.status(400).json({
        success: false,
        message: 'Search query is required'
      });
    }

    const skip = (parseInt(page) - 1) * parseInt(limit);

    // Search in lawyer specializations and user name
    const lawyers = await Lawyer.find({
      verificationStatus: 'verified',
      $or: [
        { specializations: { $regex: q, $options: 'i' } },
        { description: { $regex: q, $options: 'i' } }
      ]
    })
      .populate({
        path: 'userId',
        select: 'name email phone profilePhoto country city',
        match: {
          name: { $regex: q, $options: 'i' }
        }
      })
      .sort('-rating')
      .skip(skip)
      .limit(parseInt(limit));

    const filteredLawyers = lawyers.filter(lawyer => lawyer.userId !== null);

    res.json({
      success: true,
      data: filteredLawyers,
      count: filteredLawyers.length
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};

// @desc    Get lawyer verification status
// @route   GET /api/lawyers/:id/verification-status
// @access  Private (Lawyer only)
exports.getVerificationStatus = async (req, res) => {
  try {
    const lawyer = await Lawyer.findById(req.params.id);

    if (!lawyer) {
      return res.status(404).json({
        success: false,
        message: 'Lawyer not found'
      });
    }

    // Check ownership
    if (lawyer.userId.toString() !== req.user._id.toString()) {
      return res.status(403).json({
        success: false,
        message: 'Not authorized'
      });
    }

    const verification = await LawyerVerification.findOne({ lawyerId: lawyer._id });

    res.json({
      success: true,
      data: {
        verificationStatus: lawyer.verificationStatus,
        rejectionReason: lawyer.rejectionReason,
        verification
      }
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};
