const Payment = require('../models/Payment');
const Booking = require('../models/Booking');
const Transaction = require('../models/Transaction');
const Wallet = require('../models/Wallet');
const paymobService = require('../services/paymobService');

// @desc    Create payment
// @route   POST /api/payments/create
// @access  Private (Client only)
exports.createPayment = async (req, res) => {
  try {
    const { bookingId, paymentMethod } = req.body;

    // Get booking
    const booking = await Booking.findById(bookingId);
    if (!booking) {
      return res.status(404).json({
        success: false,
        message: 'Booking not found'
      });
    }

    // Check authorization
    if (booking.clientId.toString() !== req.user._id.toString()) {
      return res.status(403).json({
        success: false,
        message: 'Not authorized'
      });
    }

    // Check if already paid
    const existingPayment = await Payment.findOne({ 
      bookingId, 
      status: 'completed' 
    });

    if (existingPayment) {
      return res.status(400).json({
        success: false,
        message: 'Booking already paid'
      });
    }

    const amount = booking.consultationPrice;

    // Create payment record
    const payment = await Payment.create({
      userId: req.user._id,
      bookingId,
      amount,
      currency: booking.currency || 'EGP',
      paymentMethod
    });

    let responseData = { payment };

    // Handle payment based on method
    if (paymentMethod === 'wallet') {
      // Pay from wallet
      const wallet = await Wallet.findOne({ userId: req.user._id });

      if (!wallet || !wallet.canWithdraw(amount)) {
        payment.status = 'failed';
        payment.failedReason = 'Insufficient wallet balance';
        await payment.save();

        return res.status(400).json({
          success: false,
          message: 'Insufficient wallet balance'
        });
      }

      // Deduct from wallet
      await wallet.withdraw(amount);

      // Update payment
      payment.status = 'completed';
      payment.paidAt = new Date();
      await payment.save();

      // Create transaction
      await Transaction.create({
        userId: req.user._id,
        bookingId,
        type: 'booking',
        amount,
        status: 'completed',
        paymentMethod: 'wallet',
        description: `Payment for booking ${booking.bookingId}`
      });

      // Update booking
      booking.paymentStatus = 'paid';
      await booking.save();

      responseData.message = 'Payment successful';

    } else if (paymentMethod === 'card') {
      // Paymob integration
      try {
        const paymobResult = await paymobService.createPayment({
          amount,
          currency: booking.currency || 'EGP',
          orderId: payment.paymentId,
          userEmail: req.user.email,
          userPhone: req.user.phone,
          userName: req.user.name,
          bookingId: booking._id.toString()
        });

        // Update payment with Paymob details
        payment.paymobOrderId = paymobResult.orderId;
        payment.paymobToken = paymobResult.token;
        await payment.save();

        responseData.paymobToken = paymobResult.token;
        responseData.iframeUrl = paymobResult.iframeUrl;
        responseData.message = 'Payment initiated. Please complete payment.';

      } catch (error) {
        payment.status = 'failed';
        payment.failedReason = error.message;
        await payment.save();

        return res.status(500).json({
          success: false,
          message: 'Payment gateway error',
          error: error.message
        });
      }
    }

    res.json({
      success: true,
      ...responseData
    });

  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};

// @desc    Paymob callback
// @route   POST /api/payments/paymob/callback
// @access  Public
exports.paymobCallback = async (req, res) => {
  try {
    const callbackData = req.body;

    // Verify callback authenticity
    const isValid = paymobService.verifyCallback(callbackData);
    
    if (!isValid) {
      return res.status(400).json({
        success: false,
        message: 'Invalid callback'
      });
    }

    const { 
      order, 
      success: isSuccess, 
      pending,
      amount_cents,
      id: transactionId
    } = callbackData;

    // Find payment
    const payment = await Payment.findOne({ paymobOrderId: order.id });

    if (!payment) {
      return res.status(404).json({
        success: false,
        message: 'Payment not found'
      });
    }

    // Update payment
    payment.paymobTransactionId = transactionId;

    if (isSuccess && !pending) {
      payment.status = 'completed';
      payment.paidAt = new Date();
      await payment.save();

      // Create transaction
      await Transaction.create({
        userId: payment.userId,
        bookingId: payment.bookingId,
        type: 'booking',
        amount: payment.amount,
        status: 'completed',
        paymentMethod: 'card',
        paymobTransactionId: transactionId,
        paymobOrderId: order.id,
        description: `Card payment for booking`
      });

      // Update booking
      await Booking.findByIdAndUpdate(payment.bookingId, {
        paymentStatus: 'paid'
      });

    } else if (!isSuccess) {
      payment.status = 'failed';
      payment.failedReason = 'Payment declined or failed';
      await payment.save();
    }

    res.json({ success: true });

  } catch (error) {
    console.error('Paymob callback error:', error);
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};

// @desc    Get payment details
// @route   GET /api/payments/:id
// @access  Private
exports.getPayment = async (req, res) => {
  try {
    const payment = await Payment.findById(req.params.id)
      .populate('bookingId')
      .populate('userId', 'name email phone');

    if (!payment) {
      return res.status(404).json({
        success: false,
        message: 'Payment not found'
      });
    }

    // Check authorization
    if (payment.userId._id.toString() !== req.user._id.toString() && req.user.role !== 'admin') {
      return res.status(403).json({
        success: false,
        message: 'Not authorized'
      });
    }

    res.json({
      success: true,
      data: payment
    });

  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};

// @desc    Get user payments
// @route   GET /api/payments
// @access  Private
exports.getMyPayments = async (req, res) => {
  try {
    const { page = 1, limit = 10 } = req.query;
    const skip = (page - 1) * limit;

    const payments = await Payment.find({ userId: req.user._id })
      .populate('bookingId')
      .sort('-createdAt')
      .skip(skip)
      .limit(parseInt(limit));

    const total = await Payment.countDocuments({ userId: req.user._id });

    res.json({
      success: true,
      data: payments,
      pagination: {
        page: parseInt(page),
        limit: parseInt(limit),
        total,
        pages: Math.ceil(total / limit)
      }
    });

  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};
