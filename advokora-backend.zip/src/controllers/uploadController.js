const User = require('../models/User');
const Lawyer = require('../models/Lawyer');
const LawyerVerification = require('../models/LawyerVerification');
const { deleteFile } = require('../middleware/upload');

// @desc    Upload profile photo
// @route   POST /api/upload/profile
// @access  Private
exports.uploadProfile = async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({
        success: false,
        message: 'No file uploaded'
      });
    }

    const photoUrl = `/uploads/profiles/${req.file.filename}`;

    // Update user profile
    const user = await User.findByIdAndUpdate(
      req.user._id,
      { profilePhoto: photoUrl },
      { new: true }
    );

    res.json({
      success: true,
      message: 'Profile photo uploaded successfully',
      data: {
        url: photoUrl,
        filename: req.file.filename
      }
    });

  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};

// @desc    Upload verification documents
// @route   POST /api/upload/verification/:lawyerId
// @access  Private (Lawyer only)
exports.uploadVerificationDocs = async (req, res) => {
  try {
    const lawyer = await Lawyer.findById(req.params.lawyerId);

    if (!lawyer) {
      return res.status(404).json({
        success: false,
        message: 'Lawyer not found'
      });
    }

    // Check authorization
    if (lawyer.userId.toString() !== req.user._id.toString()) {
      return res.status(403).json({
        success: false,
        message: 'Not authorized'
      });
    }

    if (!req.files || Object.keys(req.files).length === 0) {
      return res.status(400).json({
        success: false,
        message: 'No files uploaded'
      });
    }

    let verification = await LawyerVerification.findOne({ lawyerId: lawyer._id });

    if (!verification) {
      verification = new LawyerVerification({ lawyerId: lawyer._id });
    }

    const uploadedFiles = {};

    // Process each uploaded file
    if (req.files.nationalIdFront) {
      const file = req.files.nationalIdFront[0];
      uploadedFiles.nationalIdFront = {
        url: `/uploads/ids/${file.filename}`,
        filename: file.filename
      };
      verification.documents.nationalIdFront = {
        url: uploadedFiles.nationalIdFront.url,
        filename: uploadedFiles.nationalIdFront.filename,
        uploadedAt: new Date(),
        status: 'pending'
      };
    }

    if (req.files.nationalIdBack) {
      const file = req.files.nationalIdBack[0];
      uploadedFiles.nationalIdBack = {
        url: `/uploads/ids/${file.filename}`,
        filename: file.filename
      };
      verification.documents.nationalIdBack = {
        url: uploadedFiles.nationalIdBack.url,
        filename: uploadedFiles.nationalIdBack.filename,
        uploadedAt: new Date(),
        status: 'pending'
      };
    }

    if (req.files.barCard) {
      const file = req.files.barCard[0];
      uploadedFiles.barCard = {
        url: `/uploads/bar-cards/${file.filename}`,
        filename: file.filename
      };
      verification.documents.barCard = {
        url: uploadedFiles.barCard.url,
        filename: uploadedFiles.barCard.filename,
        uploadedAt: new Date(),
        status: 'pending'
      };
    }

    if (req.files.personalPhoto) {
      const file = req.files.personalPhoto[0];
      uploadedFiles.personalPhoto = {
        url: `/uploads/profiles/${file.filename}`,
        filename: file.filename
      };
      verification.documents.personalPhoto = {
        url: uploadedFiles.personalPhoto.url,
        filename: uploadedFiles.personalPhoto.filename,
        uploadedAt: new Date(),
        status: 'pending'
      };
    }

    // Check if all documents are uploaded
    if (verification.areAllDocumentsUploaded()) {
      verification.status = 'under_review';
      verification.submittedAt = new Date();
      verification.addReviewHistory(req.user._id, 'submitted', 'All documents submitted for review');

      // Update lawyer status
      lawyer.verificationStatus = 'under_review';
      await lawyer.save();
    }

    await verification.save();

    res.json({
      success: true,
      message: 'Documents uploaded successfully',
      data: {
        files: uploadedFiles,
        verification: {
          status: verification.status,
          allDocsUploaded: verification.areAllDocumentsUploaded()
        }
      }
    });

  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};

// @desc    Delete file
// @route   DELETE /api/upload/:filename
// @access  Private
exports.deleteUpload = async (req, res) => {
  try {
    const { filename } = req.params;
    const { folder } = req.query;

    if (!folder) {
      return res.status(400).json({
        success: false,
        message: 'Folder parameter is required'
      });
    }

    const filePath = `/uploads/${folder}/${filename}`;
    const deleted = await deleteFile(`public${filePath}`);

    if (!deleted) {
      return res.status(404).json({
        success: false,
        message: 'File not found'
      });
    }

    res.json({
      success: true,
      message: 'File deleted successfully'
    });

  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};
