const Wallet = require('../models/Wallet');
const Transaction = require('../models/Transaction');
const paymobService = require('../services/paymobService');

// @desc    Get user wallet
// @route   GET /api/wallet
// @access  Private
exports.getWallet = async (req, res) => {
  try {
    let wallet = await Wallet.findOne({ userId: req.user._id });

    if (!wallet) {
      wallet = await Wallet.create({ userId: req.user._id });
    }

    res.json({
      success: true,
      data: wallet
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};

// @desc    Add money to wallet
// @route   POST /api/wallet/deposit
// @access  Private
exports.depositToWallet = async (req, res) => {
  try {
    const { amount } = req.body;

    if (!amount || amount <= 0) {
      return res.status(400).json({
        success: false,
        message: 'Invalid amount'
      });
    }

    let wallet = await Wallet.findOne({ userId: req.user._id });

    if (!wallet) {
      wallet = await Wallet.create({ userId: req.user._id });
    }

    // Create Paymob payment for deposit
    const paymobResult = await paymobService.createPayment({
      amount,
      currency: wallet.currency,
      orderId: `WALLET-${Date.now()}`,
      userEmail: req.user.email,
      userPhone: req.user.phone,
      userName: req.user.name,
      type: 'wallet_deposit'
    });

    // Create pending transaction
    const transaction = await Transaction.create({
      userId: req.user._id,
      walletId: wallet._id,
      type: 'walletDeposit',
      amount,
      currency: wallet.currency,
      status: 'pending',
      paymentMethod: 'card',
      paymobOrderId: paymobResult.orderId,
      description: `Deposit to wallet`
    });

    res.json({
      success: true,
      message: 'Deposit initiated',
      data: {
        transaction,
        paymobToken: paymobResult.token,
        iframeUrl: paymobResult.iframeUrl
      }
    });

  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};

// @desc    Process wallet deposit callback
// @route   POST /api/wallet/deposit/callback
// @access  Public
exports.depositCallback = async (req, res) => {
  try {
    const callbackData = req.body;

    // Verify callback
    const isValid = paymobService.verifyCallback(callbackData);
    
    if (!isValid) {
      return res.status(400).json({
        success: false,
        message: 'Invalid callback'
      });
    }

    const { 
      order, 
      success: isSuccess,
      id: transactionId,
      amount_cents
    } = callbackData;

    // Find transaction
    const transaction = await Transaction.findOne({ 
      paymobOrderId: order.id,
      type: 'walletDeposit'
    });

    if (!transaction) {
      return res.status(404).json({
        success: false,
        message: 'Transaction not found'
      });
    }

    if (isSuccess) {
      // Update transaction
      transaction.status = 'completed';
      transaction.paymobTransactionId = transactionId;
      transaction.completedAt = new Date();
      await transaction.save();

      // Add to wallet
      const wallet = await Wallet.findById(transaction.walletId);
      await wallet.deposit(transaction.amount);

    } else {
      transaction.status = 'failed';
      transaction.failedReason = 'Payment failed';
      await transaction.save();
    }

    res.json({ success: true });

  } catch (error) {
    console.error('Deposit callback error:', error);
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};

// @desc    Withdraw from wallet
// @route   POST /api/wallet/withdraw
// @access  Private
exports.withdrawFromWallet = async (req, res) => {
  try {
    const { amount, bankAccount } = req.body;

    if (!amount || amount <= 0) {
      return res.status(400).json({
        success: false,
        message: 'Invalid amount'
      });
    }

    if (!bankAccount) {
      return res.status(400).json({
        success: false,
        message: 'Bank account details required'
      });
    }

    const wallet = await Wallet.findOne({ userId: req.user._id });

    if (!wallet) {
      return res.status(404).json({
        success: false,
        message: 'Wallet not found'
      });
    }

    if (!wallet.canWithdraw(amount)) {
      return res.status(400).json({
        success: false,
        message: 'Insufficient balance'
      });
    }

    // Minimum withdrawal amount
    const minWithdraw = parseFloat(process.env.MIN_WITHDRAWAL_AMOUNT) || 100;
    if (amount < minWithdraw) {
      return res.status(400).json({
        success: false,
        message: `Minimum withdrawal amount is ${minWithdraw} ${wallet.currency}`
      });
    }

    // Create withdrawal transaction (pending admin approval)
    const transaction = await Transaction.create({
      userId: req.user._id,
      walletId: wallet._id,
      type: 'walletWithdraw',
      amount,
      currency: wallet.currency,
      status: 'pending',
      paymentMethod: 'bank_transfer',
      bankAccount,
      description: `Withdrawal request`
    });

    // Deduct from available balance and add to pending
    wallet.availableBalance -= amount;
    wallet.pendingBalance += amount;
    await wallet.save();

    res.json({
      success: true,
      message: 'Withdrawal request submitted. Will be processed within 1-3 business days.',
      data: transaction
    });

  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};

// @desc    Get wallet transactions
// @route   GET /api/wallet/transactions
// @access  Private
exports.getWalletTransactions = async (req, res) => {
  try {
    const { type, status, page = 1, limit = 20 } = req.query;
    const skip = (page - 1) * limit;

    let query = { userId: req.user._id };

    if (type) {
      query.type = type;
    }

    if (status) {
      query.status = status;
    }

    const transactions = await Transaction.find(query)
      .populate('bookingId', 'bookingId consultationType')
      .sort('-createdAt')
      .skip(skip)
      .limit(parseInt(limit));

    const total = await Transaction.countDocuments(query);

    res.json({
      success: true,
      data: transactions,
      pagination: {
        page: parseInt(page),
        limit: parseInt(limit),
        total,
        pages: Math.ceil(total / limit)
      }
    });

  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};

// @desc    Update bank account
// @route   PUT /api/wallet/bank-account
// @access  Private
exports.updateBankAccount = async (req, res) => {
  try {
    const { accountNumber, accountName, bankName, iban } = req.body;

    const wallet = await Wallet.findOne({ userId: req.user._id });

    if (!wallet) {
      return res.status(404).json({
        success: false,
        message: 'Wallet not found'
      });
    }

    wallet.bankAccount = {
      accountNumber,
      accountName,
      bankName,
      iban
    };

    await wallet.save();

    res.json({
      success: true,
      message: 'Bank account updated successfully',
      data: wallet
    });

  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};
