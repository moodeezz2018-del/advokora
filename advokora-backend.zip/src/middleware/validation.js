const { validationResult } = require('express-validator');

// Middleware to check validation errors
exports.validate = (req, res, next) => {
  const errors = validationResult(req);
  
  if (!errors.isEmpty()) {
    return res.status(400).json({
      success: false,
      message: 'Validation error',
      errors: errors.array().map(err => ({
        field: err.param,
        message: err.msg
      }))
    });
  }
  
  next();
};

// Helper to format validation errors
exports.formatErrors = (errors) => {
  return errors.array().reduce((acc, err) => {
    acc[err.param] = err.msg;
    return acc;
  }, {});
};
