const mongoose = require('mongoose');

const bookingSchema = new mongoose.Schema({
  bookingId: {
    type: String,
    required: true,
    unique: true
  },
  
  clientId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  
  lawyerId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Lawyer',
    required: true
  },
  
  consultationType: {
    type: String,
    enum: ['video', 'audio', 'chat', 'in-person'],
    required: true
  },
  
  date: {
    type: Date,
    required: true
  },
  
  time: {
    type: String,
    required: true
  },
  
  duration: {
    type: Number,
    default: 30 // minutes
  },
  
  status: {
    type: String,
    enum: ['pending', 'confirmed', 'in_progress', 'completed', 'cancelled', 'refunded'],
    default: 'pending'
  },
  
  // Pricing
  price: {
    type: Number,
    required: true
  },
  platformFee: {
    type: Number,
    required: true
  },
  totalAmount: {
    type: Number,
    required: true
  },
  currency: {
    type: String,
    default: 'EGP'
  },
  
  // Payment Reference
  paymentId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Payment',
    default: null
  },
  
  // Cancellation
  cancelReason: {
    type: String,
    default: null
  },
  cancelledBy: {
    type: String,
    enum: ['client', 'lawyer', 'admin'],
    default: null
  },
  cancelledAt: {
    type: Date,
    default: null
  },
  
  // Notes
  clientNotes: {
    type: String,
    maxlength: 500
  },
  lawyerNotes: {
    type: String,
    maxlength: 500
  },
  adminNotes: {
    type: String,
    maxlength: 500
  },
  
  // Completion
  completedAt: {
    type: Date,
    default: null
  },
  
  // Review
  isReviewed: {
    type: Boolean,
    default: false
  }
}, {
  timestamps: true
});

// Generate unique booking ID
bookingSchema.pre('save', function(next) {
  if (!this.bookingId) {
    this.bookingId = `BOOK-${Date.now()}-${Math.random().toString(36).substr(2, 9).toUpperCase()}`;
  }
  next();
});

// Index
bookingSchema.index({ clientId: 1, status: 1 });
bookingSchema.index({ lawyerId: 1, status: 1 });
bookingSchema.index({ date: 1, status: 1 });

module.exports = mongoose.model('Booking', bookingSchema);
