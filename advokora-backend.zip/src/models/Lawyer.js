const mongoose = require('mongoose');

const lawyerSchema = new mongoose.Schema({
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true,
    unique: true
  },
  
  // Professional Information
  barDegree: {
    type: String,
    enum: ['primary', 'appeal', 'cassation'],
    required: [true, 'Bar degree is required']
  },
  specializations: [{
    type: String,
    required: true
  }],
  yearsOfExperience: {
    type: Number,
    required: [true, 'Years of experience is required'],
    min: [0, 'Years of experience cannot be negative']
  },
  licenseNumber: {
    type: String,
    required: [true, 'License number is required'],
    unique: true,
    trim: true
  },
  barAssociation: {
    type: String,
    required: [true, 'Bar association is required']
  },
  
  // Pricing
  consultationPrice: {
    type: Number,
    required: [true, 'Consultation price is required'],
    min: [0, 'Price cannot be negative']
  },
  currency: {
    type: String,
    default: 'EGP'
  },
  
  // Ratings & Stats
  rating: {
    type: Number,
    default: 0,
    min: 0,
    max: 5
  },
  reviewsCount: {
    type: Number,
    default: 0
  },
  completedBookings: {
    type: Number,
    default: 0
  },
  totalEarnings: {
    type: Number,
    default: 0
  },
  
  // Verification Status
  verificationStatus: {
    type: String,
    enum: ['pending', 'under_review', 'verified', 'rejected'],
    default: 'pending'
  },
  verifiedAt: {
    type: Date,
    default: null
  },
  rejectionReason: {
    type: String,
    default: null
  },
  
  // Availability
  isAvailable: {
    type: Boolean,
    default: false
  },
  
  // Working Hours
  workingHours: {
    monday: {
      available: { type: Boolean, default: true },
      from: { type: String, default: '09:00' },
      to: { type: String, default: '17:00' }
    },
    tuesday: {
      available: { type: Boolean, default: true },
      from: { type: String, default: '09:00' },
      to: { type: String, default: '17:00' }
    },
    wednesday: {
      available: { type: Boolean, default: true },
      from: { type: String, default: '09:00' },
      to: { type: String, default: '17:00' }
    },
    thursday: {
      available: { type: Boolean, default: true },
      from: { type: String, default: '09:00' },
      to: { type: String, default: '17:00' }
    },
    friday: {
      available: { type: Boolean, default: false },
      from: { type: String, default: '09:00' },
      to: { type: String, default: '17:00' }
    },
    saturday: {
      available: { type: Boolean, default: true },
      from: { type: String, default: '09:00' },
      to: { type: String, default: '17:00' }
    },
    sunday: {
      available: { type: Boolean, default: true },
      from: { type: String, default: '09:00' },
      to: { type: String, default: '17:00' }
    }
  },
  
  // Additional Info
  languages: [{
    type: String,
    default: ['العربية']
  }],
  description: {
    type: String,
    maxlength: [1000, 'Description cannot exceed 1000 characters']
  }
}, {
  timestamps: true,
  toJSON: { virtuals: true },
  toObject: { virtuals: true }
});

// Virtual for verification documents
lawyerSchema.virtual('verification', {
  ref: 'LawyerVerification',
  localField: '_id',
  foreignField: 'lawyerId',
  justOne: true
});

// Virtual for user info
lawyerSchema.virtual('user', {
  ref: 'User',
  localField: 'userId',
  foreignField: '_id',
  justOne: true
});

// Index for search
lawyerSchema.index({ specializations: 1, verificationStatus: 1 });
lawyerSchema.index({ rating: -1, completedBookings: -1 });

module.exports = mongoose.model('Lawyer', lawyerSchema);
