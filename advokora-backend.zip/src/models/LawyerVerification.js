const mongoose = require('mongoose');

const documentSchema = new mongoose.Schema({
  url: {
    type: String,
    required: true
  },
  filename: {
    type: String,
    required: true
  },
  uploadedAt: {
    type: Date,
    default: Date.now
  },
  status: {
    type: String,
    enum: ['pending', 'approved', 'rejected'],
    default: 'pending'
  },
  rejectionReason: {
    type: String,
    default: null
  }
}, { _id: false });

const lawyerVerificationSchema = new mongoose.Schema({
  lawyerId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Lawyer',
    required: true,
    unique: true
  },
  
  // الوثائق المطلوبة
  documents: {
    // البطاقة الشخصية - الوجه
    nationalIdFront: documentSchema,
    
    // البطاقة الشخصية - الخلف
    nationalIdBack: documentSchema,
    
    // كارنيه النقابة
    barCard: documentSchema,
    
    // الصورة الشخصية
    personalPhoto: documentSchema,
    
    // وثائق إضافية (اختياري)
    additionalDocs: [{
      name: String,
      url: String,
      filename: String,
      uploadedAt: {
        type: Date,
        default: Date.now
      }
    }]
  },
  
  // معلومات التحقق
  submittedAt: {
    type: Date,
    default: null
  },
  reviewedAt: {
    type: Date,
    default: null
  },
  reviewedBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    default: null
  },
  
  // الحالة الإجمالية
  status: {
    type: String,
    enum: ['pending', 'under_review', 'approved', 'rejected', 'incomplete'],
    default: 'pending'
  },
  
  // ملاحظات الإدارة
  adminNotes: {
    type: String,
    default: null
  },
  
  // سبب الرفض العام
  rejectionReason: {
    type: String,
    default: null
  },
  
  // سجل المراجعات
  reviewHistory: [{
    reviewedBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User'
    },
    action: {
      type: String,
      enum: ['submitted', 'under_review', 'approved', 'rejected', 'resubmitted']
    },
    notes: String,
    timestamp: {
      type: Date,
      default: Date.now
    }
  }]
}, {
  timestamps: true
});

// Check if all required documents are uploaded
lawyerVerificationSchema.methods.areAllDocumentsUploaded = function() {
  return !!(
    this.documents.nationalIdFront &&
    this.documents.nationalIdBack &&
    this.documents.barCard &&
    this.documents.personalPhoto
  );
};

// Check if all documents are approved
lawyerVerificationSchema.methods.areAllDocumentsApproved = function() {
  if (!this.areAllDocumentsUploaded()) return false;
  
  return (
    this.documents.nationalIdFront.status === 'approved' &&
    this.documents.nationalIdBack.status === 'approved' &&
    this.documents.barCard.status === 'approved' &&
    this.documents.personalPhoto.status === 'approved'
  );
};

// Add review to history
lawyerVerificationSchema.methods.addReviewHistory = function(reviewedBy, action, notes = '') {
  this.reviewHistory.push({
    reviewedBy,
    action,
    notes,
    timestamp: new Date()
  });
};

// Index
lawyerVerificationSchema.index({ lawyerId: 1, status: 1 });
lawyerVerificationSchema.index({ status: 1, submittedAt: -1 });

module.exports = mongoose.model('LawyerVerification', lawyerVerificationSchema);
