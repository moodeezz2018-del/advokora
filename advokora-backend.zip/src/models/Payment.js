const mongoose = require('mongoose');

const paymentSchema = new mongoose.Schema({
  paymentId: {
    type: String,
    required: true,
    unique: true
  },
  
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  
  bookingId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Booking',
    required: true
  },
  
  amount: {
    type: Number,
    required: true
  },
  
  currency: {
    type: String,
    default: 'EGP'
  },
  
  paymentMethod: {
    type: String,
    enum: ['wallet', 'card'],
    required: true
  },
  
  // Paymob
  paymobOrderId: {
    type: String,
    default: null
  },
  
  paymobTransactionId: {
    type: String,
    default: null
  },
  
  paymobToken: {
    type: String,
    default: null
  },
  
  status: {
    type: String,
    enum: ['pending', 'completed', 'failed', 'refunded'],
    default: 'pending'
  },
  
  paidAt: {
    type: Date,
    default: null
  },
  
  refundedAt: {
    type: Date,
    default: null
  },
  
  refundAmount: {
    type: Number,
    default: 0
  },
  
  refundReason: {
    type: String,
    default: null
  },
  
  failedReason: {
    type: String,
    default: null
  },
  
  metadata: {
    type: mongoose.Schema.Types.Mixed,
    default: {}
  }
}, {
  timestamps: true
});

// Generate unique payment ID
paymentSchema.pre('save', function(next) {
  if (!this.paymentId) {
    this.paymentId = `PAY-${Date.now()}-${Math.random().toString(36).substr(2, 9).toUpperCase()}`;
  }
  next();
});

// Index
paymentSchema.index({ userId: 1, status: 1 });
paymentSchema.index({ bookingId: 1 });
paymentSchema.index({ paymobTransactionId: 1 });

module.exports = mongoose.model('Payment', paymentSchema);
