const mongoose = require('mongoose');

const reviewSchema = new mongoose.Schema({
  bookingId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Booking',
    required: true,
    unique: true
  },
  
  clientId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  
  lawyerId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Lawyer',
    required: true
  },
  
  rating: {
    type: Number,
    required: [true, 'Rating is required'],
    min: [1, 'Rating must be at least 1'],
    max: [5, 'Rating cannot exceed 5']
  },
  
  comment: {
    type: String,
    required: [true, 'Comment is required'],
    maxlength: [500, 'Comment cannot exceed 500 characters']
  },
  
  // Ratings breakdown
  professionalismRating: {
    type: Number,
    min: 1,
    max: 5,
    default: null
  },
  
  communicationRating: {
    type: Number,
    min: 1,
    max: 5,
    default: null
  },
  
  expertiseRating: {
    type: Number,
    min: 1,
    max: 5,
    default: null
  },
  
  isVisible: {
    type: Boolean,
    default: true
  },
  
  isVerified: {
    type: Boolean,
    default: true
  },
  
  // Admin moderation
  isFlagged: {
    type: Boolean,
    default: false
  },
  
  flagReason: {
    type: String,
    default: null
  },
  
  // Lawyer response
  lawyerResponse: {
    text: String,
    respondedAt: Date
  }
}, {
  timestamps: true
});

// Update lawyer's average rating after save
reviewSchema.post('save', async function() {
  const Lawyer = mongoose.model('Lawyer');
  
  const stats = await this.constructor.aggregate([
    {
      $match: { lawyerId: this.lawyerId, isVisible: true }
    },
    {
      $group: {
        _id: '$lawyerId',
        avgRating: { $avg: '$rating' },
        count: { $sum: 1 }
      }
    }
  ]);
  
  if (stats.length > 0) {
    await Lawyer.findByIdAndUpdate(this.lawyerId, {
      rating: Math.round(stats[0].avgRating * 10) / 10,
      reviewsCount: stats[0].count
    });
  }
});

// Index
reviewSchema.index({ lawyerId: 1, isVisible: 1 });
reviewSchema.index({ clientId: 1 });
reviewSchema.index({ rating: -1 });

module.exports = mongoose.model('Review', reviewSchema);
