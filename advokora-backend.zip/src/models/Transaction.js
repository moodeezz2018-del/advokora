const mongoose = require('mongoose');

const transactionSchema = new mongoose.Schema({
  transactionId: {
    type: String,
    required: true,
    unique: true
  },
  
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  
  type: {
    type: String,
    enum: ['booking', 'walletDeposit', 'walletWithdraw', 'refund', 'commission', 'transfer'],
    required: true
  },
  
  amount: {
    type: Number,
    required: true
  },
  
  currency: {
    type: String,
    default: 'EGP'
  },
  
  status: {
    type: String,
    enum: ['pending', 'completed', 'failed', 'refunded', 'cancelled'],
    default: 'pending'
  },
  
  paymentMethod: {
    type: String,
    enum: ['wallet', 'card', 'cash', 'bank_transfer'],
    default: null
  },
  
  // للحجوزات
  bookingId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Booking',
    default: null
  },
  
  // للمحفظة
  walletId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Wallet',
    default: null
  },
  
  // Paymob
  paymobTransactionId: {
    type: String,
    default: null
  },
  paymobOrderId: {
    type: String,
    default: null
  },
  
  // للسحب
  bankAccount: {
    type: String,
    default: null
  },
  
  description: {
    type: String,
    required: true
  },
  
  notes: {
    type: String,
    default: null
  },
  
  // للعمولة
  commission: {
    amount: {
      type: Number,
      default: 0
    },
    percentage: {
      type: Number,
      default: 0
    }
  },
  
  completedAt: {
    type: Date,
    default: null
  },
  
  failedReason: {
    type: String,
    default: null
  }
}, {
  timestamps: true
});

// Generate unique transaction ID
transactionSchema.pre('save', function(next) {
  if (!this.transactionId) {
    this.transactionId = `TXN-${Date.now()}-${Math.random().toString(36).substr(2, 9).toUpperCase()}`;
  }
  next();
});

// Index
transactionSchema.index({ userId: 1, status: 1 });
transactionSchema.index({ type: 1, status: 1 });
transactionSchema.index({ createdAt: -1 });

module.exports = mongoose.model('Transaction', transactionSchema);
