const mongoose = require('mongoose');

const walletSchema = new mongoose.Schema({
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true,
    unique: true
  },
  
  balance: {
    type: Number,
    default: 0,
    min: [0, 'Balance cannot be negative']
  },
  
  availableBalance: {
    type: Number,
    default: 0,
    min: [0, 'Available balance cannot be negative']
  },
  
  pendingBalance: {
    type: Number,
    default: 0,
    min: [0, 'Pending balance cannot be negative']
  },
  
  currency: {
    type: String,
    default: 'EGP'
  },
  
  isVerified: {
    type: Boolean,
    default: false
  },
  
  // Statistics
  totalDeposits: {
    type: Number,
    default: 0
  },
  
  totalWithdrawals: {
    type: Number,
    default: 0
  },
  
  totalSpent: {
    type: Number,
    default: 0
  },
  
  // Bank account for withdrawals
  bankAccount: {
    accountNumber: String,
    accountName: String,
    bankName: String,
    iban: String
  }
}, {
  timestamps: true
});

// Methods
walletSchema.methods.canWithdraw = function(amount) {
  return this.availableBalance >= amount;
};

walletSchema.methods.deposit = async function(amount) {
  this.balance += amount;
  this.availableBalance += amount;
  this.totalDeposits += amount;
  return await this.save();
};

walletSchema.methods.withdraw = async function(amount) {
  if (!this.canWithdraw(amount)) {
    throw new Error('Insufficient balance');
  }
  this.balance -= amount;
  this.availableBalance -= amount;
  this.totalWithdrawals += amount;
  return await this.save();
};

walletSchema.methods.addPending = async function(amount) {
  this.pendingBalance += amount;
  return await this.save();
};

walletSchema.methods.releasePending = async function(amount) {
  if (this.pendingBalance < amount) {
    throw new Error('Insufficient pending balance');
  }
  this.pendingBalance -= amount;
  this.availableBalance += amount;
  return await this.save();
};

module.exports = mongoose.model('Wallet', walletSchema);
