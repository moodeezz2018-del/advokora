const express = require('express');
const router = express.Router();
const { protect, authorize } = require('../middleware/auth');
const {
  // Verification
  getVerificationQueue,
  getVerificationDetails,
  approveLawyer,
  rejectLawyer,
  // Stats
  getDashboardStats,
  // Lawyers
  getAllLawyers,
  suspendLawyer,
  activateLawyer,
  // Users
  getAllUsers,
  suspendUser,
  activateUser,
  // Bookings
  getAllBookings,
  // Transactions
  getAllTransactions,
  approveWithdrawal,
  rejectWithdrawal
} = require('../controllers/adminController');

// All routes require admin authentication
router.use(protect);
router.use(authorize('admin'));

// ============ VERIFICATION ROUTES ============
router.get('/verification/queue', getVerificationQueue);
router.get('/verification/:lawyerId', getVerificationDetails);
router.put('/verification/:lawyerId/approve', approveLawyer);
router.put('/verification/:lawyerId/reject', rejectLawyer);

// ============ STATS ROUTES ============
router.get('/stats/overview', getDashboardStats);

// ============ LAWYERS ROUTES ============
router.get('/lawyers', getAllLawyers);
router.put('/lawyers/:id/suspend', suspendLawyer);
router.put('/lawyers/:id/activate', activateLawyer);

// ============ USERS ROUTES ============
router.get('/users', getAllUsers);
router.put('/users/:id/suspend', suspendUser);
router.put('/users/:id/activate', activateUser);

// ============ BOOKINGS ROUTES ============
router.get('/bookings', getAllBookings);

// ============ TRANSACTIONS ROUTES ============
router.get('/transactions', getAllTransactions);
router.put('/transactions/:id/approve-withdrawal', approveWithdrawal);
router.put('/transactions/:id/reject-withdrawal', rejectWithdrawal);

module.exports = router;
