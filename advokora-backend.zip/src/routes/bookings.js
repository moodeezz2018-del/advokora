const express = require('express');
const router = express.Router();
const { protect, authorize } = require('../middleware/auth');
const {
  createBooking,
  getMyBookings,
  getBooking,
  updateBookingStatus,
  cancelBooking
} = require('../controllers/bookingController');

// All routes are protected
router.use(protect);

router.route('/')
  .get(getMyBookings)
  .post(authorize('client'), createBooking);

router.get('/:id', getBooking);
router.put('/:id/status', authorize('lawyer'), updateBookingStatus);
router.put('/:id/cancel', authorize('client'), cancelBooking);

module.exports = router;
