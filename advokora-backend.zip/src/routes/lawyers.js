const express = require('express');
const router = express.Router();
const { protect, authorize } = require('../middleware/auth');
const {
  getLawyers,
  getLawyer,
  registerLawyer,
  updateLawyer,
  searchLawyers,
  getVerificationStatus
} = require('../controllers/lawyerController');

// Public routes
router.get('/', getLawyers);
router.get('/search', searchLawyers);
router.get('/:id', getLawyer);

// Protected routes
router.post('/register', protect, registerLawyer);
router.put('/:id', protect, authorize('lawyer'), updateLawyer);
router.get('/:id/verification-status', protect, authorize('lawyer'), getVerificationStatus);

module.exports = router;
