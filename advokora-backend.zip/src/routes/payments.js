const express = require('express');
const router = express.Router();
const { protect } = require('../middleware/auth');
const {
  createPayment,
  paymobCallback,
  getPayment,
  getMyPayments
} = require('../controllers/paymentController');

// Public routes
router.post('/paymob/callback', paymobCallback);

// Protected routes
router.use(protect);

router.post('/create', createPayment);
router.get('/', getMyPayments);
router.get('/:id', getPayment);

module.exports = router;
