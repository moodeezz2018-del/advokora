const express = require('express');
const router = express.Router();
const { protect, authorize, optionalAuth } = require('../middleware/auth');
const {
  createReview,
  getLawyerReviews,
  getReview,
  updateReview,
  deleteReview,
  respondToReview
} = require('../controllers/reviewController');

// Public routes
router.get('/lawyer/:lawyerId', optionalAuth, getLawyerReviews);
router.get('/:id', getReview);

// Protected routes
router.use(protect);

router.post('/', authorize('client'), createReview);
router.put('/:id', authorize('client'), updateReview);
router.delete('/:id', deleteReview);
router.post('/:id/response', authorize('lawyer'), respondToReview);

module.exports = router;
