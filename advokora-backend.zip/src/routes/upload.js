const express = require('express');
const router = express.Router();
const { protect, authorize } = require('../middleware/auth');
const { uploadSingle, uploadFields, processImage } = require('../middleware/upload');
const {
  uploadProfile,
  uploadVerificationDocs,
  deleteUpload
} = require('../controllers/uploadController');

// All routes are protected
router.use(protect);

// Upload profile photo
router.post('/profile', uploadSingle('profile'), processImage, uploadProfile);

// Upload verification documents
router.post(
  '/verification/:lawyerId',
  authorize('lawyer'),
  uploadFields([
    { name: 'nationalIdFront', maxCount: 1 },
    { name: 'nationalIdBack', maxCount: 1 },
    { name: 'barCard', maxCount: 1 },
    { name: 'personalPhoto', maxCount: 1 }
  ]),
  uploadVerificationDocs
);

// Delete file
router.delete('/:filename', deleteUpload);

module.exports = router;
