const express = require('express');
const router = express.Router();
const { protect } = require('../middleware/auth');
const {
  getWallet,
  depositToWallet,
  depositCallback,
  withdrawFromWallet,
  getWalletTransactions,
  updateBankAccount
} = require('../controllers/walletController');

// Public routes
router.post('/deposit/callback', depositCallback);

// Protected routes
router.use(protect);

router.get('/', getWallet);
router.post('/deposit', depositToWallet);
router.post('/withdraw', withdrawFromWallet);
router.get('/transactions', getWalletTransactions);
router.put('/bank-account', updateBankAccount);

module.exports = router;
