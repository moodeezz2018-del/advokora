const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
require('dotenv').config();

// Models
const User = require('../models/User');
const Lawyer = require('../models/Lawyer');
const LawyerVerification = require('../models/LawyerVerification');
const Wallet = require('../models/Wallet');

// Connect to database
const connectDB = async () => {
  try {
    await mongoose.connect(process.env.MONGO_URI);
    console.log('✅ MongoDB Connected');
  } catch (error) {
    console.error('❌ MongoDB connection error:', error);
    process.exit(1);
  }
};

// Create admin user
const createAdmin = async () => {
  try {
    const adminExists = await User.findOne({ email: 'admin@advokora.com' });

    if (adminExists) {
      console.log('⚠️  Admin user already exists');
      return adminExists;
    }

    const admin = await User.create({
      name: 'Admin',
      email: 'admin@advokora.com',
      phone: '+201000000000',
      password: 'Admin@123456', // Change this in production!
      role: 'admin',
      isActive: true
    });

    // Create wallet for admin
    await Wallet.create({
      userId: admin._id
    });

    console.log('✅ Admin user created successfully');
    console.log('📧 Email: admin@advokora.com');
    console.log('🔑 Password: Admin@123456');
    console.log('⚠️  PLEASE CHANGE THE PASSWORD AFTER FIRST LOGIN!');

    return admin;

  } catch (error) {
    console.error('❌ Error creating admin:', error.message);
    throw error;
  }
};

// Create sample client
const createSampleClient = async () => {
  try {
    const clientExists = await User.findOne({ email: 'client@test.com' });

    if (clientExists) {
      console.log('⚠️  Sample client already exists');
      return clientExists;
    }

    const client = await User.create({
      name: 'محمد أحمد',
      email: 'client@test.com',
      phone: '+201111111111',
      password: 'Client@123',
      role: 'client',
      country: 'مصر',
      city: 'القاهرة',
      isActive: true
    });

    // Create wallet
    await Wallet.create({
      userId: client._id,
      balance: 1000,
      availableBalance: 1000
    });

    console.log('✅ Sample client created');
    console.log('📧 Email: client@test.com');
    console.log('🔑 Password: Client@123');

    return client;

  } catch (error) {
    console.error('❌ Error creating sample client:', error.message);
    throw error;
  }
};

// Create sample lawyer
const createSampleLawyer = async () => {
  try {
    const lawyerUserExists = await User.findOne({ email: 'lawyer@test.com' });

    if (lawyerUserExists) {
      console.log('⚠️  Sample lawyer already exists');
      return lawyerUserExists;
    }

    // Create user
    const lawyerUser = await User.create({
      name: 'المحامي أحمد حسن',
      email: 'lawyer@test.com',
      phone: '+201222222222',
      password: 'Lawyer@123',
      role: 'lawyer',
      country: 'مصر',
      city: 'الإسكندرية',
      bio: 'محامي متخصص في القانون المدني والتجاري مع خبرة 10 سنوات',
      isActive: true
    });

    // Create lawyer profile
    const lawyer = await Lawyer.create({
      userId: lawyerUser._id,
      barDegree: 'محكمة النقض',
      specializations: ['قانون مدني', 'قانون تجاري', 'قانون العقارات'],
      yearsOfExperience: 10,
      licenseNumber: 'LAW-2024-001',
      barAssociation: 'نقابة المحامين المصرية',
      consultationPrice: 200,
      currency: 'EGP',
      languages: ['العربية', 'English'],
      description: 'محامي متخصص في القضايا المدنية والتجارية مع سجل حافل بالنجاحات',
      verificationStatus: 'verified',
      verifiedAt: new Date(),
      isAvailable: true,
      rating: 4.5,
      reviewsCount: 10,
      workingHours: {
        start: '09:00',
        end: '17:00'
      }
    });

    // Create verification record
    await LawyerVerification.create({
      lawyerId: lawyer._id,
      status: 'approved',
      documents: {
        nationalIdFront: {
          url: '/uploads/ids/sample-id-front.jpg',
          filename: 'sample-id-front.jpg',
          uploadedAt: new Date(),
          status: 'approved'
        },
        nationalIdBack: {
          url: '/uploads/ids/sample-id-back.jpg',
          filename: 'sample-id-back.jpg',
          uploadedAt: new Date(),
          status: 'approved'
        },
        barCard: {
          url: '/uploads/bar-cards/sample-bar-card.jpg',
          filename: 'sample-bar-card.jpg',
          uploadedAt: new Date(),
          status: 'approved'
        },
        personalPhoto: {
          url: '/uploads/profiles/sample-photo.jpg',
          filename: 'sample-photo.jpg',
          uploadedAt: new Date(),
          status: 'approved'
        }
      },
      submittedAt: new Date(),
      reviewedAt: new Date(),
      adminNotes: 'جميع المستندات صحيحة ومطابقة'
    });

    // Create wallet
    await Wallet.create({
      userId: lawyerUser._id,
      balance: 5000,
      availableBalance: 4500,
      pendingBalance: 500
    });

    console.log('✅ Sample lawyer created');
    console.log('📧 Email: lawyer@test.com');
    console.log('🔑 Password: Lawyer@123');

    return lawyerUser;

  } catch (error) {
    console.error('❌ Error creating sample lawyer:', error.message);
    throw error;
  }
};

// Clear database
const clearDatabase = async () => {
  try {
    console.log('🗑️  Clearing database...');

    await User.deleteMany({});
    await Lawyer.deleteMany({});
    await LawyerVerification.deleteMany({});
    await Wallet.deleteMany({});

    console.log('✅ Database cleared');

  } catch (error) {
    console.error('❌ Error clearing database:', error.message);
    throw error;
  }
};

// Main seed function
const seedDatabase = async (clear = false, samplesOnly = false) => {
  try {
    console.log('🌱 Starting database seeding...\n');

    await connectDB();

    if (clear) {
      await clearDatabase();
      console.log('');
    }

    // Always create admin
    await createAdmin();
    console.log('');

    // Create sample data only if requested
    if (samplesOnly) {
      await createSampleClient();
      console.log('');

      await createSampleLawyer();
      console.log('');

      console.log('✅ Database seeding completed successfully!\n');
      console.log('📝 Summary:');
      console.log('   - Admin user created');
      console.log('   - Sample client created');
      console.log('   - Sample lawyer created (verified)');
      console.log('   - Wallets created for all users\n');
    } else {
      console.log('✅ Database seeding completed successfully!\n');
      console.log('📝 Summary:');
      console.log('   - Admin user created');
      console.log('   - Ready for production use!\n');
    }

    process.exit(0);

  } catch (error) {
    console.error('❌ Seeding error:', error);
    process.exit(1);
  }
};

// Run if called directly
if (require.main === module) {
  const clearFlag = process.argv.includes('--clear');
  const samplesFlag = process.argv.includes('--samples');
  seedDatabase(clearFlag, samplesFlag);
}

module.exports = { seedDatabase, createAdmin, createSampleClient, createSampleLawyer };
