const nodemailer = require('nodemailer');

class EmailService {
  constructor() {
    this.transporter = nodemailer.createTransport({
      host: process.env.SMTP_HOST || 'smtp.gmail.com',
      port: process.env.SMTP_PORT || 587,
      secure: false,
      auth: {
        user: process.env.SMTP_USER,
        pass: process.env.SMTP_PASS
      }
    });
  }

  // Send email
  async sendEmail({ to, subject, html, text }) {
    try {
      if (!process.env.SMTP_USER || !process.env.SMTP_PASS) {
        console.log('Email not configured. Email would be sent:', { to, subject });
        return { success: true, message: 'Email service not configured' };
      }

      const mailOptions = {
        from: `"Advokora" <${process.env.SMTP_FROM || process.env.SMTP_USER}>`,
        to,
        subject,
        html,
        text
      };

      const info = await this.transporter.sendMail(mailOptions);
      console.log('Email sent:', info.messageId);
      return { success: true, messageId: info.messageId };

    } catch (error) {
      console.error('Email sending error:', error);
      throw new Error('Failed to send email');
    }
  }

  // Welcome email
  async sendWelcomeEmail(user) {
    const html = `
      <h1>مرحباً بك في Advokora</h1>
      <p>أهلاً ${user.name}،</p>
      <p>نشكرك على التسجيل في منصة Advokora لحجز المحامين.</p>
      <p>يمكنك الآن البدء في البحث عن المحامين وحجز استشارات قانونية.</p>
      <br>
      <p>مع أطيب التحيات،</p>
      <p>فريق Advokora</p>
    `;

    return this.sendEmail({
      to: user.email,
      subject: 'مرحباً بك في Advokora',
      html,
      text: `مرحباً ${user.name}، شكراً لتسجيلك في Advokora`
    });
  }

  // Booking confirmation email
  async sendBookingConfirmation(booking, client, lawyer) {
    const html = `
      <h2>تأكيد الحجز</h2>
      <p>مرحباً ${client.name}،</p>
      <p>تم تأكيد حجزك مع المحامي ${lawyer.name}</p>
      <h3>تفاصيل الحجز:</h3>
      <ul>
        <li><strong>رقم الحجز:</strong> ${booking.bookingId}</li>
        <li><strong>التاريخ:</strong> ${new Date(booking.date).toLocaleDateString('ar-EG')}</li>
        <li><strong>الوقت:</strong> ${booking.time}</li>
        <li><strong>نوع الاستشارة:</strong> ${booking.consultationType}</li>
        <li><strong>المبلغ:</strong> ${booking.consultationPrice} ${booking.currency}</li>
      </ul>
      <p>سيتم التواصل معك قبل موعد الاستشارة.</p>
      <br>
      <p>مع أطيب التحيات،</p>
      <p>فريق Advokora</p>
    `;

    return this.sendEmail({
      to: client.email,
      subject: `تأكيد حجز - ${booking.bookingId}`,
      html
    });
  }

  // Lawyer verification approved
  async sendVerificationApproved(lawyer, user) {
    const html = `
      <h2>تم الموافقة على التحقق</h2>
      <p>مبروك ${user.name}،</p>
      <p>تم الموافقة على حسابك كمحامي في منصة Advokora!</p>
      <p>يمكنك الآن البدء في استقبال الحجوزات من العملاء.</p>
      <p>تأكد من تحديث معلومات ملفك الشخصي وساعات العمل الخاصة بك.</p>
      <br>
      <p>مع أطيب التحيات،</p>
      <p>فريق Advokora</p>
    `;

    return this.sendEmail({
      to: user.email,
      subject: 'تم الموافقة على حسابك - Advokora',
      html
    });
  }

  // Lawyer verification rejected
  async sendVerificationRejected(lawyer, user, reason) {
    const html = `
      <h2>تنبيه بخصوص التحقق</h2>
      <p>مرحباً ${user.name}،</p>
      <p>نأسف لإبلاغك أنه لم تتم الموافقة على طلب التحقق الخاص بك.</p>
      <p><strong>السبب:</strong> ${reason}</p>
      <p>يمكنك تحديث المستندات وإعادة التقديم مرة أخرى.</p>
      <p>إذا كان لديك أي استفسارات، لا تتردد في التواصل معنا.</p>
      <br>
      <p>مع أطيب التحيات،</p>
      <p>فريق Advokora</p>
    `;

    return this.sendEmail({
      to: user.email,
      subject: 'تنبيه بخصوص التحقق - Advokora',
      html
    });
  }

  // Password reset email
  async sendPasswordReset(user, resetToken) {
    const resetUrl = `${process.env.FRONTEND_URL}/reset-password?token=${resetToken}`;

    const html = `
      <h2>إعادة تعيين كلمة المرور</h2>
      <p>مرحباً ${user.name}،</p>
      <p>تلقينا طلباً لإعادة تعيين كلمة المرور الخاصة بك.</p>
      <p>يرجى النقر على الرابط التالي لإعادة تعيين كلمة المرور:</p>
      <a href="${resetUrl}" style="display: inline-block; padding: 10px 20px; background-color: #4CAF50; color: white; text-decoration: none; border-radius: 5px;">إعادة تعيين كلمة المرور</a>
      <p>هذا الرابط صالح لمدة ساعة واحدة فقط.</p>
      <p>إذا لم تطلب إعادة تعيين كلمة المرور، يرجى تجاهل هذه الرسالة.</p>
      <br>
      <p>مع أطيب التحيات،</p>
      <p>فريق Advokora</p>
    `;

    return this.sendEmail({
      to: user.email,
      subject: 'إعادة تعيين كلمة المرور - Advokora',
      html
    });
  }

  // Withdrawal request notification (to admin)
  async sendWithdrawalNotification(transaction, user) {
    const html = `
      <h2>طلب سحب جديد</h2>
      <p>تم تقديم طلب سحب جديد من قبل ${user.name}</p>
      <h3>تفاصيل الطلب:</h3>
      <ul>
        <li><strong>رقم المعاملة:</strong> ${transaction.transactionId}</li>
        <li><strong>المبلغ:</strong> ${transaction.amount} ${transaction.currency}</li>
        <li><strong>الحساب البنكي:</strong> ${transaction.bankAccount}</li>
        <li><strong>التاريخ:</strong> ${new Date(transaction.createdAt).toLocaleString('ar-EG')}</li>
      </ul>
      <p>يرجى مراجعة والموافقة على الطلب من لوحة التحكم.</p>
    `;

    return this.sendEmail({
      to: process.env.ADMIN_EMAIL || process.env.SMTP_USER,
      subject: 'طلب سحب جديد - Advokora',
      html
    });
  }
}

module.exports = new EmailService();
