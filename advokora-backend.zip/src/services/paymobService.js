const axios = require('axios');
const crypto = require('crypto');

class PaymobService {
  constructor() {
    this.apiKey = process.env.PAYMOB_API_KEY;
    this.integrationId = process.env.PAYMOB_INTEGRATION_ID;
    this.iframeId = process.env.PAYMOB_IFRAME_ID;
    this.hmacSecret = process.env.PAYMOB_HMAC_SECRET;
    this.baseUrl = 'https://accept.paymob.com/api';
  }

  // Get authentication token
  async getAuthToken() {
    try {
      const response = await axios.post(`${this.baseUrl}/auth/tokens`, {
        api_key: this.apiKey
      });
      return response.data.token;
    } catch (error) {
      console.error('Paymob auth error:', error.response?.data || error.message);
      throw new Error('Failed to authenticate with Paymob');
    }
  }

  // Create order
  async createOrder(authToken, amount, orderId) {
    try {
      const response = await axios.post(`${this.baseUrl}/ecommerce/orders`, {
        auth_token: authToken,
        delivery_needed: false,
        amount_cents: amount * 100, // Convert to cents
        currency: 'EGP',
        merchant_order_id: orderId
      });
      return response.data;
    } catch (error) {
      console.error('Paymob order creation error:', error.response?.data || error.message);
      throw new Error('Failed to create order');
    }
  }

  // Get payment key
  async getPaymentKey(authToken, orderData, billingData) {
    try {
      const response = await axios.post(`${this.baseUrl}/acceptance/payment_keys`, {
        auth_token: authToken,
        amount_cents: orderData.amount_cents,
        expiration: 3600,
        order_id: orderData.id,
        billing_data: billingData,
        currency: 'EGP',
        integration_id: this.integrationId
      });
      return response.data.token;
    } catch (error) {
      console.error('Paymob payment key error:', error.response?.data || error.message);
      throw new Error('Failed to get payment key');
    }
  }

  // Main function to create payment
  async createPayment({ amount, currency, orderId, userEmail, userPhone, userName, bookingId, type }) {
    try {
      // Step 1: Get auth token
      const authToken = await this.getAuthToken();

      // Step 2: Create order
      const order = await this.createOrder(authToken, amount, orderId);

      // Step 3: Prepare billing data
      const billingData = {
        email: userEmail || 'customer@advokora.com',
        phone_number: userPhone || '+201000000000',
        first_name: userName?.split(' ')[0] || 'Customer',
        last_name: userName?.split(' ')[1] || 'Name',
        apartment: 'NA',
        floor: 'NA',
        street: 'NA',
        building: 'NA',
        shipping_method: 'NA',
        postal_code: 'NA',
        city: 'Cairo',
        country: 'EG',
        state: 'Cairo'
      };

      // Step 4: Get payment key
      const paymentToken = await this.getPaymentKey(authToken, {
        id: order.id,
        amount_cents: amount * 100
      }, billingData);

      // Return payment details
      return {
        orderId: order.id,
        token: paymentToken,
        iframeUrl: `https://accept.paymob.com/api/acceptance/iframes/${this.iframeId}?payment_token=${paymentToken}`
      };

    } catch (error) {
      console.error('Paymob payment creation error:', error);
      throw error;
    }
  }

  // Verify callback authenticity
  verifyCallback(callbackData) {
    try {
      if (!this.hmacSecret) {
        console.warn('HMAC secret not configured, skipping verification');
        return true; // Skip verification if not configured
      }

      const {
        amount_cents,
        created_at,
        currency,
        error_occured,
        has_parent_transaction,
        id,
        integration_id,
        is_3d_secure,
        is_auth,
        is_capture,
        is_refunded,
        is_standalone_payment,
        is_voided,
        order,
        owner,
        pending,
        source_data_pan,
        source_data_sub_type,
        source_data_type,
        success,
        hmac
      } = callbackData;

      // Concatenate values in specific order
      const concatenatedString = `${amount_cents}${created_at}${currency}${error_occured}${has_parent_transaction}${id}${integration_id}${is_3d_secure}${is_auth}${is_capture}${is_refunded}${is_standalone_payment}${is_voided}${order.id}${owner}${pending}${source_data_pan}${source_data_sub_type}${source_data_type}${success}`;

      // Generate HMAC
      const calculatedHmac = crypto
        .createHmac('sha512', this.hmacSecret)
        .update(concatenatedString)
        .digest('hex');

      return calculatedHmac === hmac;

    } catch (error) {
      console.error('HMAC verification error:', error);
      return false;
    }
  }

  // Refund transaction
  async refundTransaction(transactionId, amount) {
    try {
      const authToken = await this.getAuthToken();

      const response = await axios.post(`${this.baseUrl}/acceptance/void_refund/refund`, {
        auth_token: authToken,
        transaction_id: transactionId,
        amount_cents: amount * 100
      });

      return response.data;

    } catch (error) {
      console.error('Paymob refund error:', error.response?.data || error.message);
      throw new Error('Failed to process refund');
    }
  }

  // Get transaction details
  async getTransaction(transactionId) {
    try {
      const authToken = await this.getAuthToken();

      const response = await axios.get(`${this.baseUrl}/acceptance/transactions/${transactionId}`, {
        params: { token: authToken }
      });

      return response.data;

    } catch (error) {
      console.error('Paymob get transaction error:', error.response?.data || error.message);
      throw new Error('Failed to get transaction details');
    }
  }
}

module.exports = new PaymobService();
