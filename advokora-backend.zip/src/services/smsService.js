const axios = require('axios');

class SMSService {
  constructor() {
    // You can use any SMS provider (Twilio, Nexmo, etc.)
    this.provider = process.env.SMS_PROVIDER || 'twilio';
    this.accountSid = process.env.TWILIO_ACCOUNT_SID;
    this.authToken = process.env.TWILIO_AUTH_TOKEN;
    this.fromNumber = process.env.TWILIO_PHONE_NUMBER;
  }

  // Send SMS via Twilio
  async sendViaTwilio(to, message) {
    try {
      const url = `https://api.twilio.com/2010-04-01/Accounts/${this.accountSid}/Messages.json`;
      
      const response = await axios.post(url, 
        new URLSearchParams({
          To: to,
          From: this.fromNumber,
          Body: message
        }), {
          auth: {
            username: this.accountSid,
            password: this.authToken
          }
        }
      );

      console.log('SMS sent via Twilio:', response.data.sid);
      return { success: true, sid: response.data.sid };

    } catch (error) {
      console.error('Twilio SMS error:', error.response?.data || error.message);
      throw new Error('Failed to send SMS via Twilio');
    }
  }

  // Main send SMS function
  async sendSMS(to, message) {
    try {
      // Check if SMS is configured
      if (!this.accountSid || !this.authToken) {
        console.log('SMS not configured. Message would be sent:', { to, message });
        return { success: true, message: 'SMS service not configured' };
      }

      // Format phone number (ensure it starts with +)
      const formattedPhone = to.startsWith('+') ? to : `+${to}`;

      if (this.provider === 'twilio') {
        return await this.sendViaTwilio(formattedPhone, message);
      }

      throw new Error('Unsupported SMS provider');

    } catch (error) {
      console.error('SMS sending error:', error);
      throw error;
    }
  }

  // Send booking confirmation SMS
  async sendBookingConfirmation(phone, bookingId, lawyerName, date, time) {
    const message = `مرحباً! تم تأكيد حجزك ${bookingId} مع المحامي ${lawyerName} في ${date} الساعة ${time}. شكراً لاستخدامك Advokora`;
    
    return this.sendSMS(phone, message);
  }

  // Send OTP
  async sendOTP(phone, otp) {
    const message = `رمز التحقق الخاص بك في Advokora هو: ${otp}. صالح لمدة 10 دقائق.`;
    
    return this.sendSMS(phone, message);
  }

  // Send booking reminder
  async sendBookingReminder(phone, lawyerName, time) {
    const message = `تذكير: لديك استشارة مع المحامي ${lawyerName} بعد ساعة واحدة (${time}). Advokora`;
    
    return this.sendSMS(phone, message);
  }

  // Send verification approved
  async sendVerificationApproved(phone, name) {
    const message = `مبروك ${name}! تم الموافقة على حسابك كمحامي في Advokora. يمكنك الآن استقبال الحجوزات.`;
    
    return this.sendSMS(phone, message);
  }

  // Send payment confirmation
  async sendPaymentConfirmation(phone, amount, bookingId) {
    const message = `تم استلام دفعتك ${amount} جنيه للحجز ${bookingId} بنجاح. شكراً لك! Advokora`;
    
    return this.sendSMS(phone, message);
  }
}

module.exports = new SMSService();
