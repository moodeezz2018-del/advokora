// User roles
exports.USER_ROLES = {
  CLIENT: 'client',
  LAWYER: 'lawyer',
  ADMIN: 'admin'
};

// Lawyer specializations
exports.SPECIALIZATIONS = [
  'قانون جنائي',
  'قانون مدني',
  'قانون تجاري',
  'قانون العمل',
  'قانون الأسرة',
  'قانون العقارات',
  'قانون الشركات',
  'قانون الضرائب',
  'قانون الملكية الفكرية',
  'قانون البنوك',
  'قانون التأمين',
  'قانون البيئة',
  'قانون البحري',
  'قانون الطيران',
  'قانون الرياضة',
  'قانون الإنترنت والتكنولوجيا',
  'التحكيم والوساطة'
];

// Bar degrees
exports.BAR_DEGREES = {
  COURT_OF_FIRST_INSTANCE: 'محكمة أول درجة',
  COURT_OF_APPEAL: 'محكمة الاستئناف',
  COURT_OF_CASSATION: 'محكمة النقض',
  HIGH_COURT: 'المحكمة العليا'
};

// Consultation types
exports.CONSULTATION_TYPES = {
  VIDEO_CALL: 'video_call',
  PHONE_CALL: 'phone_call',
  IN_PERSON: 'in_person',
  CHAT: 'chat'
};

// Booking statuses
exports.BOOKING_STATUS = {
  PENDING: 'pending',
  CONFIRMED: 'confirmed',
  COMPLETED: 'completed',
  CANCELLED: 'cancelled',
  REJECTED: 'rejected'
};

// Payment statuses
exports.PAYMENT_STATUS = {
  PENDING: 'pending',
  COMPLETED: 'completed',
  FAILED: 'failed',
  REFUNDED: 'refunded'
};

// Transaction types
exports.TRANSACTION_TYPES = {
  BOOKING: 'booking',
  WALLET_DEPOSIT: 'walletDeposit',
  WALLET_WITHDRAW: 'walletWithdraw',
  REFUND: 'refund',
  COMMISSION: 'commission',
  TRANSFER: 'transfer'
};

// Transaction statuses
exports.TRANSACTION_STATUS = {
  PENDING: 'pending',
  COMPLETED: 'completed',
  FAILED: 'failed',
  REFUNDED: 'refunded',
  CANCELLED: 'cancelled'
};

// Verification statuses
exports.VERIFICATION_STATUS = {
  PENDING: 'pending',
  UNDER_REVIEW: 'under_review',
  APPROVED: 'approved',
  REJECTED: 'rejected',
  VERIFIED: 'verified'
};

// Document statuses
exports.DOCUMENT_STATUS = {
  PENDING: 'pending',
  APPROVED: 'approved',
  REJECTED: 'rejected'
};

// Payment methods
exports.PAYMENT_METHODS = {
  WALLET: 'wallet',
  CARD: 'card',
  CASH: 'cash',
  BANK_TRANSFER: 'bank_transfer'
};

// File upload limits
exports.FILE_LIMITS = {
  MAX_SIZE: 5 * 1024 * 1024, // 5MB
  ALLOWED_TYPES: ['image/jpeg', 'image/jpg', 'image/png', 'application/pdf'],
  IMAGE_TYPES: ['image/jpeg', 'image/jpg', 'image/png']
};

// Default commission rate (10%)
exports.DEFAULT_COMMISSION_RATE = 0.10;

// Minimum withdrawal amount
exports.MIN_WITHDRAWAL_AMOUNT = 100;

// OTP settings
exports.OTP_SETTINGS = {
  LENGTH: 6,
  EXPIRY_MINUTES: 10
};

// JWT settings
exports.JWT_SETTINGS = {
  EXPIRE: '7d',
  COOKIE_EXPIRE: 7 // days
};

// Pagination defaults
exports.PAGINATION = {
  DEFAULT_PAGE: 1,
  DEFAULT_LIMIT: 10,
  MAX_LIMIT: 100
};

// Working hours defaults
exports.DEFAULT_WORKING_HOURS = {
  start: '09:00',
  end: '17:00'
};

// Countries
exports.COUNTRIES = {
  EGYPT: 'مصر',
  SAUDI_ARABIA: 'السعودية',
  UAE: 'الإمارات',
  KUWAIT: 'الكويت',
  QATAR: 'قطر',
  BAHRAIN: 'البحرين',
  OMAN: 'عمان'
};

// Cities in Egypt
exports.EGYPT_CITIES = [
  'القاهرة',
  'الجيزة',
  'الإسكندرية',
  'الإسماعيلية',
  'أسوان',
  'أسيوط',
  'الأقصر',
  'البحر الأحمر',
  'البحيرة',
  'بني سويف',
  'بورسعيد',
  'جنوب سيناء',
  'الدقهلية',
  'دمياط',
  'سوهاج',
  'السويس',
  'الشرقية',
  'شمال سيناء',
  'الغربية',
  'الفيوم',
  'القليوبية',
  'قنا',
  'كفر الشيخ',
  'مطروح',
  'المنوفية',
  'المنيا',
  'الوادي الجديد'
];

// Languages
exports.LANGUAGES = [
  'العربية',
  'English',
  'Français',
  'Deutsch',
  'Español'
];

// Review ratings
exports.RATING_RANGE = {
  MIN: 1,
  MAX: 5
};

// Error messages
exports.ERROR_MESSAGES = {
  UNAUTHORIZED: 'غير مصرح بالوصول',
  FORBIDDEN: 'ليس لديك صلاحية',
  NOT_FOUND: 'غير موجود',
  VALIDATION_ERROR: 'خطأ في البيانات المدخلة',
  SERVER_ERROR: 'خطأ في الخادم',
  INSUFFICIENT_BALANCE: 'رصيد غير كافي',
  BOOKING_ALREADY_PAID: 'تم الدفع بالفعل',
  BOOKING_NOT_AVAILABLE: 'الموعد غير متاح',
  FILE_TOO_LARGE: 'حجم الملف كبير جداً',
  INVALID_FILE_TYPE: 'نوع الملف غير مدعوم'
};

// Success messages
exports.SUCCESS_MESSAGES = {
  REGISTRATION_SUCCESS: 'تم التسجيل بنجاح',
  LOGIN_SUCCESS: 'تم تسجيل الدخول بنجاح',
  UPDATE_SUCCESS: 'تم التحديث بنجاح',
  DELETE_SUCCESS: 'تم الحذف بنجاح',
  BOOKING_CREATED: 'تم إنشاء الحجز بنجاح',
  PAYMENT_SUCCESS: 'تم الدفع بنجاح',
  VERIFICATION_APPROVED: 'تمت الموافقة على التحقق',
  EMAIL_SENT: 'تم إرسال البريد الإلكتروني'
};

// Notification types
exports.NOTIFICATION_TYPES = {
  BOOKING: 'booking',
  PAYMENT: 'payment',
  VERIFICATION: 'verification',
  MESSAGE: 'message',
  REVIEW: 'review',
  REMINDER: 'reminder'
};

// Time slots interval (in minutes)
exports.TIME_SLOT_INTERVAL = 60;

module.exports = exports;
