// Generate random OTP
exports.generateOTP = (length = 6) => {
  let otp = '';
  for (let i = 0; i < length; i++) {
    otp += Math.floor(Math.random() * 10);
  }
  return otp;
};

// Generate unique ID
exports.generateUniqueId = (prefix = 'ID') => {
  const timestamp = Date.now();
  const random = Math.random().toString(36).substr(2, 9).toUpperCase();
  return `${prefix}-${timestamp}-${random}`;
};

// Format currency
exports.formatCurrency = (amount, currency = 'EGP') => {
  return new Intl.NumberFormat('ar-EG', {
    style: 'currency',
    currency: currency
  }).format(amount);
};

// Format date
exports.formatDate = (date, locale = 'ar-EG') => {
  return new Date(date).toLocaleDateString(locale, {
    year: 'numeric',
    month: 'long',
    day: 'numeric'
  });
};

// Format time
exports.formatTime = (date, locale = 'ar-EG') => {
  return new Date(date).toLocaleTimeString(locale, {
    hour: '2-digit',
    minute: '2-digit'
  });
};

// Validate Egyptian phone number
exports.isValidEgyptianPhone = (phone) => {
  // Accepts: +201234567890 or 01234567890
  const regex = /^(\+20|0)?1[0-2,5]{1}[0-9]{8}$/;
  return regex.test(phone);
};

// Sanitize user input
exports.sanitizeInput = (input) => {
  if (typeof input !== 'string') return input;
  
  return input
    .trim()
    .replace(/[<>]/g, '') // Remove < and >
    .replace(/javascript:/gi, '') // Remove javascript: protocol
    .replace(/on\w+=/gi, ''); // Remove event handlers
};

// Paginate results
exports.paginate = (page = 1, limit = 10) => {
  const p = parseInt(page);
  const l = parseInt(limit);
  
  return {
    skip: (p - 1) * l,
    limit: l,
    page: p
  };
};

// Calculate pagination info
exports.getPaginationInfo = (total, page, limit) => {
  return {
    total,
    page: parseInt(page),
    limit: parseInt(limit),
    pages: Math.ceil(total / limit),
    hasNext: page * limit < total,
    hasPrev: page > 1
  };
};

// Sleep function for delays
exports.sleep = (ms) => {
  return new Promise(resolve => setTimeout(resolve, ms));
};

// Generate random string
exports.randomString = (length = 10) => {
  return Math.random().toString(36).substring(2, length + 2);
};

// Check if time slot is available
exports.isTimeSlotAvailable = (workingHours, requestedTime) => {
  // workingHours format: { start: '09:00', end: '17:00' }
  // requestedTime format: '14:30'
  
  if (!workingHours || !workingHours.start || !workingHours.end) {
    return true; // If no working hours set, accept all
  }
  
  const [reqHour, reqMin] = requestedTime.split(':').map(Number);
  const [startHour, startMin] = workingHours.start.split(':').map(Number);
  const [endHour, endMin] = workingHours.end.split(':').map(Number);
  
  const reqMinutes = reqHour * 60 + reqMin;
  const startMinutes = startHour * 60 + startMin;
  const endMinutes = endHour * 60 + endMin;
  
  return reqMinutes >= startMinutes && reqMinutes <= endMinutes;
};

// Calculate commission
exports.calculateCommission = (amount, rate = 0.10) => {
  const commission = amount * rate;
  const netAmount = amount - commission;
  
  return {
    grossAmount: amount,
    commission,
    commissionRate: rate * 100, // as percentage
    netAmount
  };
};

// Get file extension
exports.getFileExtension = (filename) => {
  return filename.split('.').pop().toLowerCase();
};

// Check if file is image
exports.isImageFile = (filename) => {
  const imageExtensions = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
  const ext = exports.getFileExtension(filename);
  return imageExtensions.includes(ext);
};

// Generate booking time slots
exports.generateTimeSlots = (startTime = '09:00', endTime = '17:00', interval = 60) => {
  const slots = [];
  const [startHour, startMin] = startTime.split(':').map(Number);
  const [endHour, endMin] = endTime.split(':').map(Number);
  
  let currentMinutes = startHour * 60 + startMin;
  const endMinutes = endHour * 60 + endMin;
  
  while (currentMinutes < endMinutes) {
    const hour = Math.floor(currentMinutes / 60);
    const min = currentMinutes % 60;
    slots.push(`${String(hour).padStart(2, '0')}:${String(min).padStart(2, '0')}`);
    currentMinutes += interval;
  }
  
  return slots;
};

// Mask sensitive data
exports.maskEmail = (email) => {
  const [name, domain] = email.split('@');
  const maskedName = name.charAt(0) + '***' + name.charAt(name.length - 1);
  return `${maskedName}@${domain}`;
};

exports.maskPhone = (phone) => {
  return phone.slice(0, 3) + '****' + phone.slice(-3);
};

// Deep clone object
exports.deepClone = (obj) => {
  return JSON.parse(JSON.stringify(obj));
};

// Check if date is in past
exports.isPastDate = (date) => {
  return new Date(date) < new Date();
};

// Check if date is today
exports.isToday = (date) => {
  const today = new Date();
  const checkDate = new Date(date);
  
  return today.getDate() === checkDate.getDate() &&
         today.getMonth() === checkDate.getMonth() &&
         today.getFullYear() === checkDate.getFullYear();
};

// Get date range
exports.getDateRange = (startDate, endDate) => {
  const dates = [];
  let currentDate = new Date(startDate);
  const end = new Date(endDate);
  
  while (currentDate <= end) {
    dates.push(new Date(currentDate));
    currentDate.setDate(currentDate.getDate() + 1);
  }
  
  return dates;
};
